import { useCallback, useEffect, useRef, useState } from 'react';
import type { DrawingLayer, DrawingStroke } from '@/lib/types';

export type DrawTool = DrawingStroke['tool'] | 'pan' | 'lasso';

interface Props {
  layers: DrawingLayer[];
  onChange: (layers: DrawingLayer[]) => void;
  active: boolean;
  color: string;
  width: number;
  opacity: number;
  tool: DrawTool;
}

const ERASER_THRESHOLD = 14;

export default function DrawingCanvas({ layers, onChange, active, color, width, opacity, tool }: Props) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const drawing = useRef(false);
  const currentPoints = useRef<number[]>([]);
  const [zoom, setZoom] = useState(1);
  const [pan, setPan] = useState({ x: 0, y: 0 });
  const panning = useRef<{ sx: number; sy: number; ox: number; oy: number } | null>(null);
  const lassoPath = useRef<number[]>([]);
  const [lassoActive, setLassoActive] = useState(false);
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());

  const redraw = useCallback(() => {
    const canvas = canvasRef.current;
    const container = containerRef.current;
    if (!canvas || !container) return;
    const rect = container.getBoundingClientRect();
    if (canvas.width !== rect.width || canvas.height !== rect.height) {
      canvas.width = rect.width;
      canvas.height = rect.height;
    }
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.save();
    ctx.translate(pan.x, pan.y);
    ctx.scale(zoom, zoom);
    const sorted = [...layers].sort((a, b) => a.order - b.order);
    for (const layer of sorted) {
      if (!layer.visible) continue;
      for (const s of layer.strokes) {
        ctx.save();
        ctx.globalAlpha = s.opacity;
        ctx.strokeStyle = s.color;
        ctx.fillStyle = s.color;
        ctx.lineWidth = s.width;
        ctx.lineCap = s.tool === 'pencil' ? 'round' : 'round';
        if (s.tool === 'highlighter') {
          ctx.globalAlpha = 0.3 * s.opacity;
          ctx.lineWidth = s.width * 3;
        }
        if (s.tool === 'eraser') {
          ctx.globalCompositeOperation = 'destination-out';
          ctx.strokeStyle = 'rgba(0,0,0,1)';
          ctx.lineWidth = s.width * 3;
        }
        if (s.tool === 'neon') {
          ctx.shadowColor = s.color;
          ctx.shadowBlur = 12;
        }
        if (s.tool === 'line' && s.points.length >= 4) {
          ctx.beginPath();
          ctx.moveTo(s.points[0], s.points[1]);
          ctx.lineTo(s.points[s.points.length - 2], s.points[s.points.length - 1]);
          ctx.stroke();
        } else if (s.tool === 'rect' && s.points.length >= 4) {
          const x = Math.min(s.points[0], s.points[s.points.length - 2]);
          const y = Math.min(s.points[1], s.points[s.points.length - 1]);
          const w = Math.abs(s.points[s.points.length - 2] - s.points[0]);
          const h = Math.abs(s.points[s.points.length - 1] - s.points[1]);
          ctx.strokeRect(x, y, w, h);
        } else if (s.tool === 'circle' && s.points.length >= 4) {
          const cx = (s.points[0] + s.points[s.points.length - 2]) / 2;
          const cy = (s.points[1] + s.points[s.points.length - 1]) / 2;
          const rx = Math.abs(s.points[s.points.length - 2] - s.points[0]) / 2;
          const ry = Math.abs(s.points[s.points.length - 1] - s.points[1]) / 2;
          ctx.beginPath();
          ctx.ellipse(cx, cy, rx, ry, 0, 0, Math.PI * 2);
          ctx.stroke();
        } else {
          ctx.beginPath();
          ctx.moveTo(s.points[0], s.points[1]);
          for (let i = 2; i < s.points.length; i += 2) {
            ctx.lineTo(s.points[i], s.points[i + 1]);
          }
          if (s.tool === 'brush' || s.tool === 'pencil') ctx.stroke();
          else ctx.stroke();
        }
        // selected outline
        if (selectedIds.has(s.id)) {
          ctx.strokeStyle = '#4A90D9';
          ctx.setLineDash([4, 4]);
          ctx.lineWidth = 1;
          const xs = s.points.filter((_, i) => i % 2 === 0);
          const ys = s.points.filter((_, i) => i % 2 === 1);
          const minX = Math.min(...xs) - 6, maxX = Math.max(...xs) + 6;
          const minY = Math.min(...ys) - 6, maxY = Math.max(...ys) + 6;
          ctx.strokeRect(minX, minY, maxX - minX, maxY - minY);
        }
        ctx.restore();
      }
    }
    ctx.restore();
    if (lassoPath.current.length >= 4) {
      ctx.save();
      ctx.strokeStyle = '#4A90D9';
      ctx.setLineDash([5, 5]);
      ctx.beginPath();
      ctx.moveTo(lassoPath.current[0], lassoPath.current[1]);
      for (let i = 2; i < lassoPath.current.length; i += 2) {
        ctx.lineTo(lassoPath.current[i], lassoPath.current[i + 1]);
      }
      ctx.stroke();
      ctx.restore();
    }
  }, [layers, pan, zoom, selectedIds]);

  useEffect(() => {
    redraw();
  }, [redraw]);

  useEffect(() => {
    const onResize = () => redraw();
    window.addEventListener('resize', onResize);
    return () => window.removeEventListener('resize', onResize);
  }, [redraw]);

  const toCanvas = (e: React.PointerEvent): [number, number] => {
    const rect = containerRef.current!.getBoundingClientRect();
    return [
      (e.clientX - rect.left - pan.x) / zoom,
      (e.clientY - rect.top - pan.y) / zoom,
    ];
  };

  const topLayer = (): DrawingLayer => {
    if (layers.length) return layers[layers.length - 1];
    return { id: 'layer-1', strokes: [], visible: true, opacity: 1, order: 0 };
  };

  const hitTest = (x: number, y: number): string | null => {
    for (let li = layers.length - 1; li >= 0; li--) {
      for (let si = layers[li].strokes.length - 1; si >= 0; si--) {
        const s = layers[li].strokes[si];
        if (s.tool === 'eraser') continue;
        for (let i = 0; i < s.points.length; i += 2) {
          const dx = s.points[i] - x;
          const dy = s.points[i + 1] - y;
          if (dx * dx + dy * dy < (ERASER_THRESHOLD + s.width) ** 2) return s.id;
        }
      }
    }
    return null;
  };

  const onPointerDown = (e: React.PointerEvent) => {
    if (!active) return;
    (e.target as Element).setPointerCapture(e.pointerId);
    const [x, y] = toCanvas(e);
    if (tool === 'pan' || e.button === 1) {
      panning.current = { sx: e.clientX, sy: e.clientY, ox: pan.x, oy: pan.y };
      return;
    }
    if (tool === 'lasso') {
      lassoPath.current = [x, y];
      setLassoActive(true);
      return;
    }
    if (tool === 'eraser') {
      drawing.current = true;
      const hit = hitTest(x, y);
      if (hit) {
        onChange(
          layers.map((l) => ({ ...l, strokes: l.strokes.filter((s) => s.id !== hit) }))
        );
      }
      return;
    }
    drawing.current = true;
    currentPoints.current = [x, y];
  };

  const onPointerMove = (e: React.PointerEvent) => {
    if (!active) return;
    const [x, y] = toCanvas(e);
    if (panning.current) {
      setPan({
        x: panning.current.ox + (e.clientX - panning.current.sx),
        y: panning.current.oy + (e.clientY - panning.current.sy),
      });
      return;
    }
    if (lassoActive) {
      lassoPath.current = [...lassoPath.current, x, y];
      redraw();
      return;
    }
    if (!drawing.current) return;
    if (tool === 'eraser') {
      const hit = hitTest(x, y);
      if (hit) {
        onChange(
          layers.map((l) => ({ ...l, strokes: l.strokes.filter((s) => s.id !== hit) }))
        );
      }
      return;
    }
    currentPoints.current = [...currentPoints.current, x, y];
    redraw();
  };

  const onPointerUp = () => {
    if (panning.current) {
      panning.current = null;
      return;
    }
    if (lassoActive) {
      // select strokes intersecting the lasso bounding box
      const xs = lassoPath.current.filter((_, i) => i % 2 === 0);
      const ys = lassoPath.current.filter((_, i) => i % 2 === 1);
      const minX = Math.min(...xs), maxX = Math.max(...xs);
      const minY = Math.min(...ys), maxY = Math.max(...ys);
      const sel = new Set<string>();
      for (const l of layers) {
        for (const s of l.strokes) {
          for (let i = 0; i < s.points.length; i += 2) {
            const px = s.points[i], py = s.points[i + 1];
            if (px >= minX && px <= maxX && py >= minY && py <= maxY) {
              sel.add(s.id);
              break;
            }
          }
        }
      }
      setSelectedIds(sel);
      lassoPath.current = [];
      setLassoActive(false);
      return;
    }
    if (!drawing.current) return;
    drawing.current = false;
    if (currentPoints.current.length >= 2) {
      const stroke: DrawingStroke = {
        id: `s-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
        tool: tool === 'pan' || tool === 'lasso' ? 'pen' : tool,
        color,
        width,
        opacity,
        points: currentPoints.current,
      };
      const updated = [...layers];
      if (updated.length === 0) {
        updated.push(topLayer());
      }
      const li = updated.length - 1;
      updated[li] = { ...updated[li], strokes: [...updated[li].strokes, stroke] };
      onChange(updated);
    }
    currentPoints.current = [];
  };

  // live preview of the stroke being drawn
  useEffect(() => {
    if (!drawing.current || currentPoints.current.length < 4) return;
    const canvas = canvasRef.current;
    const ctx = canvas?.getContext('2d');
    if (!ctx || !canvas) return;
    ctx.save();
    ctx.translate(pan.x, pan.y);
    ctx.scale(zoom, zoom);
    ctx.globalAlpha = opacity;
    ctx.strokeStyle = color;
    ctx.lineWidth = width;
    ctx.lineCap = 'round';
    ctx.beginPath();
    ctx.moveTo(currentPoints.current[0], currentPoints.current[1]);
    for (let i = 2; i < currentPoints.current.length; i += 2) {
      ctx.lineTo(currentPoints.current[i], currentPoints.current[i + 1]);
    }
    ctx.stroke();
    ctx.restore();
  });

  const cursor = !active ? 'default' : tool === 'pan' ? 'grab' : tool === 'eraser' ? 'cell' : 'crosshair';

  return (
    <div
      ref={containerRef}
      className="absolute inset-0"
      style={{ touchAction: active ? (tool === 'pan' ? 'auto' : 'none') : 'auto', cursor, zIndex: active ? 10 : 0, pointerEvents: active ? 'auto' : 'none' }}
      onPointerDown={onPointerDown}
      onPointerMove={onPointerMove}
      onPointerUp={onPointerUp}
      onPointerLeave={onPointerUp}
    >
      <canvas ref={canvasRef} className="w-full h-full" />
      {selectedIds.size > 0 && (
        <div className="absolute top-2 left-1/2 -translate-x-1/2 hd-card px-3 py-1.5 flex gap-2 z-20">
          <button
            className="hd-btn text-xs !py-1"
            onClick={() => {
              onChange(
                layers.map((l) => ({ ...l, strokes: l.strokes.filter((s) => !selectedIds.has(s.id)) }))
              );
              setSelectedIds(new Set());
            }}
          >
            Delete {selectedIds.size}
          </button>
          <button className="hd-btn text-xs !py-1" onClick={() => setSelectedIds(new Set())}>
            Done
          </button>
        </div>
      )}
    </div>
  );
}

export function DrawingControls({
  tool, setTool, color, setColor, width, setWidth, opacity, setOpacity, onUndo, onRedo, canUndo, canRedo, zoom, setZoom,
}: {
  tool: DrawTool; setTool: (t: DrawTool) => void;
  color: string; setColor: (c: string) => void;
  width: number; setWidth: (w: number) => void;
  opacity: number; setOpacity: (o: number) => void;
  onUndo: () => void; onRedo: () => void; canUndo: boolean; canRedo: boolean;
  zoom: number; setZoom: (z: number) => void;
}) {
  const TOOLS: { id: DrawTool; label: string }[] = [
    { id: 'pen', label: 'Pen' },
    { id: 'pencil', label: 'Pencil' },
    { id: 'highlighter', label: 'Highlighter' },
    { id: 'brush', label: 'Brush' },
    { id: 'neon', label: 'Neon' },
    { id: 'eraser', label: 'Eraser' },
    { id: 'line', label: 'Line' },
    { id: 'rect', label: 'Rect' },
    { id: 'circle', label: 'Circle' },
    { id: 'pan', label: 'Pan' },
    { id: 'lasso', label: 'Lasso' },
  ];
  const COLORS = ['#49382E', '#B99A79', '#C05B4D', '#E58F4A', '#E8B94A', '#6B9A6E', '#6FA6C9', '#A98BC0', '#FFFFFF', '#000000'];
  return (
    <div className="flex flex-wrap items-center gap-2">
      <div className="flex gap-1 overflow-x-auto">
        {TOOLS.map((tt) => (
          <button
            key={tt.id}
            className="hd-btn text-xs !py-1.5 !px-2.5 whitespace-nowrap"
            style={tool === tt.id ? { background: 'var(--accent)', color: 'var(--accent-contrast)' } : {}}
            onClick={() => setTool(tt.id)}
          >
            {tt.label}
          </button>
        ))}
      </div>
      <div className="flex gap-1">
        {COLORS.map((c) => (
          <button
            key={c}
            className="w-5 h-5 rounded-full border"
            style={{ background: c, borderColor: c === color ? 'var(--text)' : 'var(--border)', transform: c === color ? 'scale(1.15)' : undefined }}
            onClick={() => setColor(c)}
            aria-label={`Color ${c}`}
          />
        ))}
      </div>
      <label className="text-xs flex items-center gap-1" style={{ color: 'var(--text-2)' }}>
        W
        <input type="range" min={1} max={24} value={width} onChange={(e) => setWidth(Number(e.target.value))} className="w-16" />
      </label>
      <label className="text-xs flex items-center gap-1" style={{ color: 'var(--text-2)' }}>
        O
        <input type="range" min={0.1} max={1} step={0.1} value={opacity} onChange={(e) => setOpacity(Number(e.target.value))} className="w-14" />
      </label>
      <label className="text-xs flex items-center gap-1" style={{ color: 'var(--text-2)' }}>
        Z
        <input type="range" min={0.25} max={5} step={0.25} value={zoom} onChange={(e) => setZoom(Number(e.target.value))} className="w-14" />
      </label>
      <button className="hd-btn text-xs !py-1.5" disabled={!canUndo} onClick={onUndo}>Undo</button>
      <button className="hd-btn text-xs !py-1.5" disabled={!canRedo} onClick={onRedo}>Redo</button>
    </div>
  );
}
