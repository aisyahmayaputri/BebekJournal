import { useEffect, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Plus, FilePlus, Tag as TagIcon, FolderPlus, X } from 'lucide-react';

interface Props {
  onNewTag?: () => void;
}

/**
 * Floating action button pinned to the bottom-right corner.
 * Collapsed: a single + icon. Click expands a small popup with
 * three options: New Entry, New Tag, New Folder.
 */
export default function FabMenu({ onNewTag }: Props) {
  const nav = useNavigate();
  const [open, setOpen] = useState(false);
  const [tagModal, setTagModal] = useState(false);
  const [tagName, setTagName] = useState('');
  const [tagBusy, setTagBusy] = useState(false);
  const rootRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!open) return;
    const onDoc = (e: MouseEvent) => {
      if (rootRef.current && !rootRef.current.contains(e.target as Node)) setOpen(false);
    };
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && setOpen(false);
    document.addEventListener('mousedown', onDoc);
    document.addEventListener('keydown', onKey);
    return () => {
      document.removeEventListener('mousedown', onDoc);
      document.removeEventListener('keydown', onKey);
    };
  }, [open]);

  const go = (path: string) => {
    setOpen(false);
    nav(path);
  };

  const createTag = async () => {
    if (!tagName.trim()) return;
    setTagBusy(true);
    try {
      const { dataApi } = await import('@/lib/data');
      await dataApi.createTag(tagName.trim());
      setTagName('');
      setTagModal(false);
      setOpen(false);
    } finally {
      setTagBusy(false);
    }
  };

  return (
    <div
      ref={rootRef}
      className="fixed z-40 flex flex-col items-end gap-2"
      style={{
        bottom: 'calc(1.25rem + env(safe-area-inset-bottom, 0px))',
        right: 'calc(1rem + env(safe-area-inset-right, 0px))',
      }}
    >
      {/* modal for new tag */}
      {tagModal && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4"
          style={{ background: 'rgba(0,0,0,0.45)' }}
          onClick={() => setTagModal(false)}
        >
          <div
            className="hd-card p-5 w-full max-w-xs pop-in"
            style={{ background: 'var(--surface)' }}
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between mb-3">
              <h3 className="font-bold" style={{ color: 'var(--text)' }}>New Tag</h3>
              <button onClick={() => setTagModal(false)} aria-label="Close" className="hd-btn !p-1.5">
                <X className="w-4 h-4" />
              </button>
            </div>
            <input
              className="hd-input mb-3"
              placeholder="Tag name"
              value={tagName}
              autoFocus
              onChange={(e) => setTagName(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && createTag()}
            />
            <button className="hd-btn hd-btn-primary w-full justify-center" onClick={createTag} disabled={tagBusy || !tagName.trim()}>
              {tagBusy ? 'Creating…' : 'Create'}
            </button>
          </div>
        </div>
      )}

      {/* menu options */}
      {open && (
        <div className="pop-in flex flex-col gap-2 items-end">
          <MenuOption icon={<FilePlus className="w-4 h-4" />} label="New Entry" onClick={() => go('/editor/new')} delay={0} />
          <MenuOption icon={<TagIcon className="w-4 h-4" />} label="New Tag" onClick={() => { setOpen(false); setTagModal(true); }} delay={1} />
          <MenuOption icon={<FolderPlus className="w-4 h-4" />} label="New Folder" onClick={() => go('/folders?new=1')} delay={2} />
        </div>
      )}

      {/* main FAB */}
      <button
        className={`w-14 h-14 rounded-full hd-btn hd-btn-primary !p-0 !border-2 shadow-lg flex items-center justify-center springy ${open ? 'fab-open' : ''}`}
        style={{ background: 'var(--accent)', color: 'var(--accent-contrast)' }}
        onClick={() => setOpen((o) => !o)}
        aria-label={open ? 'Close create menu' : 'Create new entry'}
        aria-expanded={open}
        title={open ? 'Close' : 'Create new entry'}
      >
        <Plus className="w-7 h-7" />
      </button>
    </div>
  );
}

function MenuOption({
  icon, label, onClick, delay,
}: {
  icon: React.ReactNode; label: string; onClick: () => void; delay: number;
}) {
  return (
    <button
      className="hd-btn hd-card-hover text-sm pop-in items-center wiggle-hover"
      style={{ animationDelay: `${delay * 40}ms` }}
      onClick={onClick}
    >
      <span style={{ color: 'var(--accent)' }}>{icon}</span> {label}
    </button>
  );
}
