import { useEffect, useRef, useState } from 'react';

export interface FormatState {
  bold: boolean;
  italic: boolean;
  underline: boolean;
  strike: boolean;
}

export function execFormat(cmd: string, value?: string) {
  document.execCommand(cmd, false, value);
}

export function queryFormatState(): FormatState {
  return {
    bold: document.queryCommandState('bold'),
    italic: document.queryCommandState('italic'),
    underline: document.queryCommandState('underline'),
    strike: document.queryCommandState('strikeThrough'),
  };
}

export interface ToolbarProps {
  onFormat: (cmd: string, value?: string) => void;
  onFontSize: (size: string) => void;
  onColor: (color: string) => void;
  onHighlight: (color: string) => void;
  onInsertDivider: (kind: 'line' | 'stars' | 'hearts') => void;
  onLink: (url: string, label: string) => void;
  fontSize: string;
  color: string;
  highlight: string;
}

const TEXT_COLORS = ['#49382E', '#857466', '#B99A79', '#C05B4D', '#6B9A6E', '#6FA6C9', '#A98BC0'];
const HL_COLORS = ['#FFF3B0', '#FFD6A5', '#C9E4C9', '#CDE1F0', '#F4C9D8'];

export default function FormatToolbar(props: ToolbarProps) {
  const [fmt, setFmt] = useState<FormatState>(() => ({
    bold: false, italic: false, underline: false, strike: false,
  }));

  useEffect(() => {
    const update = () => {
      const sel = document.getSelection();
      if (!sel || !sel.anchorNode) return;
      const anchorEl = sel.anchorNode.nodeType === Node.ELEMENT_NODE
        ? (sel.anchorNode as Element)
        : sel.anchorNode.parentElement;
      if (!anchorEl?.closest('#entry-rich-text')) return;
      setFmt(queryFormatState());
    };
    document.addEventListener('selectionchange', update);
    return () => document.removeEventListener('selectionchange', update);
  }, []);

  const [showColors, setShowColors] = useState(false);
  const [showHl, setShowHl] = useState(false);
  const [showLink, setShowLink] = useState(false);
  const [linkUrl, setLinkUrl] = useState('');
  const [linkLabel, setLinkLabel] = useState('');
  const ref = useRef<HTMLDivElement>(null);

  const Group = ({ children }: { children: React.ReactNode }) => (
    <div className="flex items-center gap-1 px-2 border-r" style={{ borderColor: 'var(--border)' }}>
      {children}
    </div>
  );

  const TBtn = ({
    onClick, active, title, children,
  }: {
    onClick: () => void; active?: boolean; title: string; children: React.ReactNode;
  }) => (
    <button
      type="button"
      title={title}
      aria-label={title}
      onMouseDown={(e) => e.preventDefault()}
      onClick={onClick}
      className="w-8 h-8 rounded-lg flex items-center justify-center text-sm font-bold transition-colors"
      style={{
        color: active ? 'var(--accent-contrast)' : 'var(--text)',
        background: active ? 'var(--accent)' : 'transparent',
      }}
    >
      {children}
    </button>
  );

  return (
    <div
      ref={ref}
      className="hd-card flex items-center overflow-x-auto py-1.5 px-1"
      style={{ background: 'var(--surface)' }}
    >
      <Group>
        <select
          className="hd-input !w-auto !py-1 !px-2 text-sm"
          value={props.fontSize}
          onChange={(e) => props.onFontSize(e.target.value)}
          title="Text size"
        >
          <option value="2">Small</option>
          <option value="3">Normal</option>
          <option value="4">Large</option>
          <option value="5">Huge</option>
        </select>
      </Group>
      <Group>
        <TBtn title="Bold" active={fmt.bold} onClick={() => props.onFormat('bold')}><b>B</b></TBtn>
        <TBtn title="Italic" active={fmt.italic} onClick={() => props.onFormat('italic')}><i>I</i></TBtn>
        <TBtn title="Underline" active={fmt.underline} onClick={() => props.onFormat('underline')}><u>U</u></TBtn>
        <TBtn title="Strikethrough" active={fmt.strike} onClick={() => props.onFormat('strikeThrough')}><s>S</s></TBtn>
      </Group>
      <Group>
        <TBtn title="Bullet list" onClick={() => props.onFormat('insertUnorderedList')}>•≡</TBtn>
        <TBtn title="Numbered list" onClick={() => props.onFormat('insertOrderedList')}>1≡</TBtn>
        <TBtn title="Quote" onClick={() => props.onFormat('formatBlock', 'blockquote')}>❝</TBtn>
        <TBtn title="Code block" onClick={() => props.onFormat('formatBlock', 'pre')}>{'</>'}</TBtn>
        <TBtn title="Heading" onClick={() => props.onFormat('formatBlock', 'h1')}>H1</TBtn>
        <TBtn title="Subheading" onClick={() => props.onFormat('formatBlock', 'h2')}>H2</TBtn>
      </Group>
      <Group>
        <TBtn title="Text color" active={showColors} onClick={() => { setShowColors(!showColors); setShowHl(false); }}>A</TBtn>
        <TBtn title="Highlight" active={showHl} onClick={() => { setShowHl(!showHl); setShowColors(false); }}>
          <span style={{ background: 'var(--warning)', borderRadius: 3, padding: '0 3px' }}>ab</span>
        </TBtn>
        <TBtn title="Insert link" active={showLink} onClick={() => setShowLink(!showLink)}>
          <u>🔗</u>
        </TBtn>
      </Group>
      <Group>
        <TBtn title="Divider line" onClick={() => props.onInsertDivider('line')}>—</TBtn>
        <TBtn title="Star divider" onClick={() => props.onInsertDivider('stars')}>✶✶✶</TBtn>
        <TBtn title="Heart divider" onClick={() => props.onInsertDivider('hearts')}>♥♥♥</TBtn>
      </Group>

      {showColors && (
        <div className="absolute bottom-14 left-1/2 -translate-x-1/2 hd-card p-2 flex gap-1.5 z-20">
          {TEXT_COLORS.map((c) => (
            <button
              key={c}
              className="w-6 h-6 rounded-full border"
              style={{ background: c, borderColor: 'var(--border)' }}
              onClick={() => { props.onColor(c); setShowColors(false); }}
              aria-label={`Text color ${c}`}
            />
          ))}
        </div>
      )}
      {showHl && (
        <div className="absolute bottom-14 left-1/2 -translate-x-1/2 hd-card p-2 flex gap-1.5 z-20">
          {HL_COLORS.map((c) => (
            <button
              key={c}
              className="w-6 h-6 rounded-full border"
              style={{ background: c, borderColor: 'var(--border)' }}
              onClick={() => { props.onHighlight(c); setShowHl(false); }}
              aria-label={`Highlight ${c}`}
            />
          ))}
        </div>
      )}
      {showLink && (
        <div className="absolute bottom-14 left-1/2 -translate-x-1/2 hd-card p-3 flex flex-col gap-2 z-20 w-64">
          <input className="hd-input text-sm" placeholder="https://…" value={linkUrl} onChange={(e) => setLinkUrl(e.target.value)} />
          <input className="hd-input text-sm" placeholder="Label (e.g. My Instagram)" value={linkLabel} onChange={(e) => setLinkLabel(e.target.value)} />
          <div className="flex gap-2">
            <button
              className="hd-btn hd-btn-primary text-sm flex-1 justify-center"
              onClick={() => {
                if (linkUrl && /^https?:\/\//i.test(linkUrl)) {
                  props.onLink(linkUrl, linkLabel || linkUrl);
                }
                setShowLink(false);
                setLinkUrl('');
                setLinkLabel('');
              }}
            >
              Apply
            </button>
            <button className="hd-btn text-sm" onClick={() => setShowLink(false)}>×</button>
          </div>
        </div>
      )}
    </div>
  );
}
