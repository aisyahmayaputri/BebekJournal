import { useEffect, useMemo, useState } from 'react';
import { ArrowLeft, Loader2, ChartNoAxesCombined, BookOpen, Film, MapPin, NotebookPen, Heart } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { dataApi } from '@/lib/data';
import { MOOD_COLORS, type Entry, type MoodLog } from '@/lib/types';

export default function StatsPage() {
  const nav = useNavigate();
  const [entries, setEntries] = useState<Entry[]>([]);
  const [logs, setLogs] = useState<MoodLog[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      try {
        const [e, l] = await Promise.all([dataApi.listEntries(), dataApi.listMoodLogs()]);
        setEntries(e);
        setLogs(l);
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  const stats = useMemo(() => {
    const year = String(new Date().getFullYear());
    const thisYear = entries.filter((e) => e.date.startsWith(year));
    const moodCounts = new Map<string, { count: number; totalIntensity: number }>();
    for (const log of logs) {
      for (const m of log.moods) {
        const cur = moodCounts.get(m.label) ?? { count: 0, totalIntensity: 0 };
        cur.count += 1;
        cur.totalIntensity += m.intensity;
        moodCounts.set(m.label, cur);
      }
    }
    const topMoods = [...moodCounts.entries()]
      .sort((a, b) => b[1].count - a[1].count)
      .slice(0, 5);
    const avgIntensity =
      logs.reduce((acc, l) => acc + l.moods.reduce((s, m) => s + m.intensity, 0), 0) /
      Math.max(1, logs.reduce((acc, l) => acc + l.moods.length, 0));
    return {
      diary: entries.filter((e) => e.type === 'diary').length,
      books: thisYear.filter((e) => e.type === 'book').length,
      movies: thisYear.filter((e) => e.type === 'movie').length,
      hangouts: thisYear.filter((e) => e.type === 'hangout').length,
      topMoods,
      avgIntensity: isFinite(avgIntensity) ? avgIntensity.toFixed(1) : '—',
      moodDays: logs.length,
    };
  }, [entries, logs]);

  if (loading) {
    return (
      <div className="flex justify-center py-20">
        <Loader2 className="w-8 h-8 animate-spin" style={{ color: 'var(--accent)' }} />
      </div>
    );
  }

  return (
    <div className="space-y-5 fade-up">
      <div className="flex items-center justify-between">
        <button className="hd-btn !p-2" onClick={() => nav('/')} aria-label="Back">
          <ArrowLeft className="w-5 h-5" />
        </button>
        <h1 className="text-2xl font-bold flex items-center gap-2" style={{ color: 'var(--text)' }}>
          <ChartNoAxesCombined className="w-6 h-6" style={{ color: 'var(--accent)' }} /> Statistics
        </h1>
        <span className="w-10" />
      </div>

      <div className="grid grid-cols-2 gap-3">
        <StatCard icon={<NotebookPen className="w-5 h-5" />} label="Diary entries" value={stats.diary} />
        <StatCard icon={<BookOpen className="w-5 h-5" />} label="Books this year" value={stats.books} />
        <StatCard icon={<Film className="w-5 h-5" />} label="Movies this year" value={stats.movies} />
        <StatCard icon={<MapPin className="w-5 h-5" />} label="Hangouts this year" value={stats.hangouts} />
      </div>

      <div className="hd-card p-5">
        <h2 className="font-bold mb-3 flex items-center gap-2" style={{ color: 'var(--text)' }}>
          <Heart className="w-5 h-5" style={{ color: 'var(--accent)' }} /> Mood overview
        </h2>
        <div className="grid grid-cols-2 gap-4 mb-4">
          <div>
            <p className="text-3xl font-bold" style={{ color: 'var(--accent)' }}>{stats.moodDays}</p>
            <p className="text-sm" style={{ color: 'var(--text-2)' }}>days with mood logs</p>
          </div>
          <div>
            <p className="text-3xl font-bold" style={{ color: 'var(--accent)' }}>{stats.avgIntensity}</p>
            <p className="text-sm" style={{ color: 'var(--text-2)' }}>average intensity</p>
          </div>
        </div>
        {stats.topMoods.length === 0 ? (
          <p className="text-sm" style={{ color: 'var(--text-2)' }}>
            Log your mood on the Home page or Mood Tracker to see trends here.
          </p>
        ) : (
          <div className="space-y-2">
            {stats.topMoods.map(([label, data]) => {
              const max = stats.topMoods[0][1].count || 1;
              const color = MOOD_COLORS[label] ?? 'var(--accent)';
              return (
                <div key={label} className="flex items-center gap-2">
                  <span className="w-24 text-sm truncate" style={{ color: 'var(--text)' }}>{label}</span>
                  <div className="flex-1 h-5 rounded-full overflow-hidden" style={{ background: 'var(--surface-2)' }}>
                    <div className="h-full rounded-full" style={{ width: `${(data.count / max) * 100}%`, background: color }} />
                  </div>
                  <span className="w-8 text-right text-sm font-bold" style={{ color: 'var(--text-2)' }}>{data.count}</span>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}

function StatCard({ icon, label, value }: { icon: React.ReactNode; label: string; value: number }) {
  return (
    <div className="hd-card p-4">
      <div className="flex items-center gap-2 mb-1" style={{ color: 'var(--accent)' }}>
        {icon}
        <span className="text-xs" style={{ color: 'var(--text-2)' }}>{label}</span>
      </div>
      <p className="text-3xl font-bold" style={{ color: 'var(--text)' }}>{value}</p>
    </div>
  );
}
