import { useEffect, useMemo, useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { BookOpen, Film, MapPin, NotebookPen, Loader2, Search, FolderOpen, Tag as TagIcon } from 'lucide-react';
import { dataApi } from '@/lib/data';
import { useI18n } from '@/lib/i18n';
import type { Entry, EntryType, Tag, Folder } from '@/lib/types';

const TYPE_ICON: Record<EntryType, React.ReactNode> = {
  diary: <NotebookPen className="w-4 h-4" />,
  movie: <Film className="w-4 h-4" />,
  book: <BookOpen className="w-4 h-4" />,
  hangout: <MapPin className="w-4 h-4" />,
};

const TYPE_LABEL: Record<EntryType, string> = {
  diary: 'Diary',
  movie: 'Movie',
  book: 'Book',
  hangout: 'Hangout',
};

export function EntryTypeBadge({ type }: { type: EntryType }) {
  return (
    <span
      className="inline-flex items-center gap-1 text-xs px-2 py-0.5 rounded-full"
      style={{
        background: 'var(--surface-2)',
        color: 'var(--text-2)',
        border: '1px solid var(--border)',
      }}
    >
      {TYPE_ICON[type]} {TYPE_LABEL[type]}
    </span>
  );
}

export function EntryCard({
  entry,
  tags,
  onClick,
}: {
  entry: Entry;
  tags: Tag[];
  onClick: () => void;
}) {
  const theme = entry.blocks.theme;
  const preview = entry.content
    ? entry.content.replace(/<[^>]+>/g, ' ').replace(/&nbsp;/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 110)
    : '';
  return (
    <button
      onClick={onClick}
      className="hd-card hd-card-hover p-4 text-left w-full card-pop"
      style={{
        background: theme?.bgColor ?? 'var(--surface)',
        borderColor: theme?.outlineColor ?? 'var(--outline)',
      }}
    >
      <div className="flex items-center justify-between gap-2 mb-1.5">
        <EntryTypeBadge type={entry.type} />
        <span className="text-xs" style={{ color: 'var(--text-2)' }}>
          {entry.date}
        </span>
      </div>
      <p
        className="font-bold truncate"
        style={{ color: theme?.textColor ?? 'var(--text)', fontFamily: theme?.fontFamily }}
      >
        {entry.title || 'Untitled'}
      </p>
      {preview && (
        <p className="text-xs mt-1 line-clamp-2" style={{ color: 'var(--text-2)' }}>
          {preview}
        </p>
      )}
      {(entry.type === 'movie' || entry.type === 'book') && (
        <p className="text-sm truncate" style={{ color: theme?.textColor ?? 'var(--text-2)' }}>
          {entry.type === 'movie'
            ? entry.blocks.movie?.movieTitle
            : `${entry.blocks.book?.bookTitle ?? ''}${entry.blocks.book?.author ? ' — ' + entry.blocks.book.author : ''}`}
        </p>
      )}
      {entry.type === 'hangout' && entry.blocks.hangout?.placeName && (
        <p className="text-sm truncate" style={{ color: theme?.textColor ?? 'var(--text-2)' }}>
          <MapPin className="inline w-3.5 h-3.5" /> {entry.blocks.hangout.placeName}
        </p>
      )}
      {tags.length > 0 && (
        <div className="flex flex-wrap gap-1 mt-2">
          {tags.map((tg) => (
            <span
              key={tg.id}
              className="text-xs px-2 py-0.5 rounded-full"
              style={{ background: tg.chip_bg, color: tg.chip_text }}
            >
              {tg.name}
            </span>
          ))}
        </div>
      )}
    </button>
  );
}

export default function LibraryPage() {
  const { t } = useI18n();
  const nav = useNavigate();
  const [params] = useSearchParams();
  const [entries, setEntries] = useState<Entry[]>([]);
  const [tags, setTags] = useState<Tag[]>([]);
  const [folders, setFolders] = useState<Folder[]>([]);
  const [entryTags, setEntryTags] = useState<Map<string, string[]>>(new Map());
  const [entryFolders, setEntryFolders] = useState<Map<string, string[]>>(new Map());
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const [search, setSearch] = useState('');
  const [typeFilter, setTypeFilter] = useState<EntryType[]>([]);
  const [tagFilter, setTagFilter] = useState<string[]>([]);
  const [folderFilter, setFolderFilter] = useState<string>('');
  const [dateFrom, setDateFrom] = useState('');
  const [dateTo, setDateTo] = useState('');

  // honor ?type= query from Home links
  useEffect(() => {
    const tp = params.get('type');
    if (tp && ['diary', 'movie', 'book', 'hangout'].includes(tp)) {
      setTypeFilter([tp as EntryType]);
    }
  }, [params]);

  const load = async () => {
    setLoading(true);
    setError(null);
    try {
      const [es, tg, fd, et, ef] = await Promise.all([
        dataApi.listEntries(),
        dataApi.listTags(),
        dataApi.listFolders(),
        dataApi.listEntryTags(),
        dataApi.listEntryFolders(),
      ]);
      setEntries(es);
      setTags(tg);
      setFolders(fd);
      const m = new Map<string, string[]>();
      for (const r of et) {
        m.set(r.entry_id, [...(m.get(r.entry_id) ?? []), r.tag_id]);
      }
      setEntryTags(m);
      const fm = new Map<string, string[]>();
      for (const r of ef) {
        fm.set(r.entry_id, [...(fm.get(r.entry_id) ?? []), r.folder_id]);
      }
      setEntryFolders(fm);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Failed to load');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
  }, []);

  const filtered = useMemo(() => {
    const s = search.trim().toLowerCase();
    return entries.filter((e) => {
      if (typeFilter.length && !typeFilter.includes(e.type)) return false;
      if (folderFilter && !(entryFolders.get(e.id) ?? []).includes(folderFilter)) return false;
      if (tagFilter.length) {
        const et = entryTags.get(e.id) ?? [];
        if (!tagFilter.every((tg) => et.includes(tg))) return false;
      }
      if (dateFrom && e.date < dateFrom) return false;
      if (dateTo && e.date > dateTo) return false;
      if (s) {
        const hay = [
          e.title,
          e.content,
          e.blocks.book?.bookTitle,
          e.blocks.book?.author,
          e.blocks.movie?.movieTitle,
          e.blocks.hangout?.placeName,
        ]
          .filter(Boolean)
          .join(' ')
          .toLowerCase();
        if (!hay.includes(s)) return false;
      }
      return true;
    });
  }, [entries, typeFilter, tagFilter, folderFilter, dateFrom, dateTo, search, entryTags, entryFolders]);

  const groups = useMemo(() => {
    const g = new Map<string, Entry[]>();
    for (const e of filtered) {
      g.set(e.date, [...(g.get(e.date) ?? []), e]);
    }
    return [...g.entries()].sort((a, b) => b[0].localeCompare(a[0]));
  }, [filtered]);

  const toggleType = (ty: EntryType) => {
    setTypeFilter((prev) => (prev.includes(ty) ? prev.filter((x) => x !== ty) : [...prev, ty]));
  };

  const toggleTag = (id: string) => {
    setTagFilter((prev) => (prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]));
  };

  return (
    <div className="space-y-5 fade-up">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <h1 className="text-2xl font-bold" style={{ color: 'var(--text)' }}>
          {t('library')}
        </h1>
        <button className="hd-btn hd-btn-primary" onClick={() => nav('/editor/new')}>
          + {t('newEntry')}
        </button>
      </div>

      {/* search + filters */}
      <div className="hd-card p-4 space-y-3">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4" style={{ color: 'var(--text-2)' }} />
          <input
            className="hd-input !pl-9"
            placeholder={t('search') + '…'}
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
        <div className="flex flex-wrap gap-2">
          {(['diary', 'movie', 'book', 'hangout'] as EntryType[]).map((ty) => (
            <button
              key={ty}
              className="hd-btn text-sm"
              style={typeFilter.includes(ty) ? { background: 'var(--surface-2)' } : {}}
              onClick={() => toggleType(ty)}
            >
              {TYPE_ICON[ty]} {TYPE_LABEL[ty]}
            </button>
          ))}
        </div>
        {tags.length > 0 && (
          <div className="flex flex-wrap gap-1.5">
            {tags.map((tg) => (
              <button
                key={tg.id}
                onClick={() => toggleTag(tg.id)}
                className="text-xs px-2.5 py-1 rounded-full border transition-opacity"
                style={{
                  background: tg.chip_bg,
                  color: tg.chip_text,
                  borderColor: tg.chip_text,
                  opacity: tagFilter.length && !tagFilter.includes(tg.id) ? 0.4 : 1,
                }}
              >
                <TagIcon className="inline w-3 h-3 mr-1" />
                {tg.name}
              </button>
            ))}
          </div>
        )}
        <div className="flex flex-wrap gap-2 items-center">
          {folders.length > 0 && (
            <select className="hd-input !w-auto text-sm" value={folderFilter} onChange={(e) => setFolderFilter(e.target.value)}>
              <option value="">{t('filterByFolder')}</option>
              {folders.map((f) => (
                <option key={f.id} value={f.id}>
                  {f.name}
                </option>
              ))}
            </select>
          )}
          <input type="date" className="hd-input !w-auto text-sm" value={dateFrom} onChange={(e) => setDateFrom(e.target.value)} aria-label="From date" />
          <span style={{ color: 'var(--text-2)' }}>→</span>
          <input type="date" className="hd-input !w-auto text-sm" value={dateTo} onChange={(e) => setDateTo(e.target.value)} aria-label="To date" />
        </div>
      </div>

      {loading ? (
        <div className="flex justify-center py-16">
          <Loader2 className="w-8 h-8 animate-spin" style={{ color: 'var(--accent)' }} />
        </div>
      ) : error ? (
        <div className="hd-card p-6 text-center">
          <p style={{ color: 'var(--error)' }}>{error}</p>
          <button className="hd-btn mt-3" onClick={load}>
            Retry
          </button>
        </div>
      ) : filtered.length === 0 ? (
        <div className="hd-card p-10 text-center">
          <FolderOpen className="w-10 h-10 mx-auto mb-3" style={{ color: 'var(--outline)' }} />
          <p style={{ color: 'var(--text-2)' }}>{t('noEntries')}</p>
        </div>
      ) : (
        groups.map(([date, dayEntries]) => (
          <section key={date}>
            <h3 className="text-sm font-bold mb-2 px-1" style={{ color: 'var(--text-2)' }}>
              {date}
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
              {dayEntries.map((e) => (
                <EntryCard
                  key={e.id}
                  entry={e}
                  tags={(entryTags.get(e.id) ?? []).map((id) => tags.find((tg) => tg.id === id)!).filter(Boolean)}
                  onClick={() => nav(`/entry/${e.id}`)}
                />
              ))}
            </div>
          </section>
        ))
      )}
    </div>
  );
}
