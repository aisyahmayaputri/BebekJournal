import { useEffect, useMemo, useState } from 'react';
import { ArrowLeft, Loader2, Save, Smile, Plus, Pencil, Palette } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { dataApi } from '@/lib/data';
import { useI18n } from '@/lib/i18n';
import { MoodIcon } from '@/pages/HomePage';
import { MOOD_ICONS, MOOD_COLORS, type MoodDef, type MoodLog, type MoodRef } from '@/lib/types';

type View = 'day' | 'week' | 'month' | 'year';

function iso(d: Date) {
  return d.toISOString().slice(0, 10);
}

export default function MoodTrackerPage() {
  const { t } = useI18n();
  const nav = useNavigate();
  const [view, setView] = useState<View>('day');
  const [moodDefs, setMoodDefs] = useState<MoodDef[]>([]);
  const [logs, setLogs] = useState<MoodLog[]>([]);
  const [selectedDate, setSelectedDate] = useState(iso(new Date()));
  const [draft, setDraft] = useState<MoodRef[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [editing, setEditing] = useState(false);

  useEffect(() => {
    (async () => {
      try {
        const [m, l] = await Promise.all([dataApi.listMoods(), dataApi.listMoodLogs()]);
        setMoodDefs(m);
        setLogs(l);
        const today = l.find((x) => x.date === iso(new Date()));
        if (today) setDraft(today.moods);
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  const refetchLog = async (date: string) => {
    const all = await dataApi.listMoodLogs(date, date);
    const log = all[0] ?? null;
    setLogs((prev) => [...prev.filter((x) => x.date !== date), ...(log ? [log] : [])]);
    return log;
  };

  const toggleMood = (m: MoodDef) => {
    setDraft((prev) =>
      prev.some((x) => x.moodId === m.id)
        ? prev.filter((x) => x.moodId !== m.id)
        : [...prev, { moodId: m.id, label: m.label, color: m.color, intensity: 5 }]
    );
    setSaved(false);
  };

  const setIntensity = (moodId: string, intensity: number) => {
    setDraft((prev) => prev.map((x) => (x.moodId === moodId ? { ...x, intensity } : x)));
    setSaved(false);
  };

  const save = async () => {
    setSaving(true);
    try {
      await dataApi.upsertMoodLog(selectedDate, draft);
      await refetchLog(selectedDate);
      setSaved(true);
      setEditing(false);
    } finally {
      setSaving(false);
    }
  };

  const addCustomMood = async () => {
    const label = prompt('New emotion name');
    if (!label?.trim()) return;
    const color = MOOD_COLORS[label.trim()] ?? '#B99A79';
    const m = await dataApi.createMood(label.trim(), color);
    setMoodDefs((prev) => [...prev, m]);
  };

  // aggregates
  const monthLogs = useMemo(() => {
    const prefix = selectedDate.slice(0, 7);
    return logs.filter((l) => l.date.startsWith(prefix));
  }, [logs, selectedDate]);

  const emotionFrequency = useMemo(() => {
    const counts = new Map<string, number>();
    for (const log of logs) {
      for (const m of log.moods) {
        counts.set(m.label, (counts.get(m.label) ?? 0) + 1);
      }
    }
    return [...counts.entries()].sort((a, b) => b[1] - a[1]).slice(0, 8);
  }, [logs]);

  if (loading) {
    return (
      <div className="flex justify-center py-20">
        <Loader2 className="w-8 h-8 animate-spin" style={{ color: 'var(--accent)' }} />
      </div>
    );
  }

  const existingLog = logs.find((l) => l.date === selectedDate);

  return (
    <div className="space-y-5 fade-up">
      <div className="flex items-center justify-between">
        <button className="hd-btn !p-2" onClick={() => nav('/')} aria-label="Back">
          <ArrowLeft className="w-5 h-5" />
        </button>
        <h1 className="text-2xl font-bold" style={{ color: 'var(--text)' }}>
          {t('moodTracker')}
        </h1>
        <button className="hd-btn !p-2" onClick={addCustomMood} title="Add emotion">
          <Plus className="w-5 h-5" />
        </button>
      </div>

      {/* view switcher */}
      <div className="flex gap-2 flex-wrap">
        {(['day', 'week', 'month', 'year'] as View[]).map((v) => (
          <button
            key={v}
            className="hd-btn text-sm capitalize"
            style={view === v ? { background: 'var(--surface-2)' } : {}}
            onClick={() => setView(v)}
          >
            {v}
          </button>
        ))}
      </div>

      {view === 'day' && (
        <>
          <div className="hd-card p-4">
            <label className="text-sm font-semibold" style={{ color: 'var(--text-2)' }}>
              Date
            </label>
            <input
              type="date"
              className="hd-input mt-1"
              value={selectedDate}
              onChange={async (e) => {
                const d = e.target.value;
                setSelectedDate(d);
                const log = await refetchLog(d);
                setDraft(log?.moods ?? []);
                setSaved(false);
              }}
            />
          </div>

          <div className="hd-card p-4">
            <h2 className="font-bold mb-3 flex items-center gap-2" style={{ color: 'var(--text)' }}>
              <Smile className="w-5 h-5" style={{ color: 'var(--accent)' }} />
              {t('howAreYouFeeling')}
            </h2>
            <div className="flex flex-wrap gap-2">
              {moodDefs.map((m) => {
                const on = draft.some((x) => x.moodId === m.id);
                return (
                  <button
                    key={m.id}
                    onClick={() => toggleMood(m)}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full border-2 text-sm font-semibold transition-transform hover:scale-105"
                    style={{
                      background: on ? m.color + '26' : 'var(--surface)',
                      color: on ? m.color : 'var(--text-2)',
                      borderColor: on ? m.color : 'var(--border)',
                    }}
                  >
                    <MoodIcon name={MOOD_ICONS[m.label] ?? 'smile'} className="w-4 h-4" />
                    {m.label}
                  </button>
                );
              })}
            </div>
          </div>

          {draft.length > 0 && (
            <div className="hd-card p-4 space-y-3">
              {draft.map((m) => (
                <div key={m.moodId} className="flex items-center gap-3">
                  <span className="w-24 text-sm font-semibold truncate" style={{ color: m.color }}>
                    {m.label}
                  </span>
                  <input
                    type="range"
                    min={1}
                    max={10}
                    value={m.intensity}
                    onChange={(e) => setIntensity(m.moodId, Number(e.target.value))}
                    className="flex-1"
                    style={{ accentColor: m.color }}
                  />
                  <span className="w-8 text-right font-bold" style={{ color: m.color }}>
                    {m.intensity}
                  </span>
                </div>
              ))}
              <button className="hd-btn hd-btn-primary w-full justify-center" onClick={save} disabled={saving}>
                <Save className="w-4 h-4" /> {saving ? 'Saving…' : existingLog ? t('editMood') : t('saveMood')}
              </button>
              {saved && (
                <p className="text-sm text-center" style={{ color: 'var(--success)' }}>
                  {t('moodSaved')}
                </p>
              )}
            </div>
          )}
        </>
      )}

      {view === 'month' && (
        <div className="hd-card p-4">
          <h2 className="font-bold mb-3" style={{ color: 'var(--text)' }}>
            {selectedDate.slice(0, 7)} — daily moods
          </h2>
          <div className="grid grid-cols-7 gap-1.5">
            {(() => {
              const [y, mo] = selectedDate.slice(0, 7).split('-').map(Number);
              const days = new Date(y, mo, 0).getDate();
              return Array.from({ length: days }, (_, i) => {
                const d = `${selectedDate.slice(0, 7)}-${String(i + 1).padStart(2, '0')}`;
                const log = logs.find((l) => l.date === d);
                const top = log?.moods?.slice().sort((a, b) => b.intensity - a.intensity)[0];
                return (
                  <button
                    key={d}
                    onClick={() => { setView('day'); setSelectedDate(d); refetchLog(d).then((l) => setDraft(l?.moods ?? [])); }}
                    className="aspect-square rounded-lg border flex flex-col items-center justify-center text-xs"
                    style={{
                      background: top ? top.color + '30' : 'var(--surface-2)',
                      borderColor: top ? top.color : 'var(--border)',
                      color: 'var(--text-2)',
                    }}
                    title={log?.moods.map((m) => `${m.label} ${m.intensity}`).join(', ')}
                  >
                    {i + 1}
                    {top && <span className="w-2 h-2 rounded-full mt-0.5" style={{ background: top.color }} />}
                  </button>
                );
              });
            })()}
          </div>
          <p className="text-xs mt-2" style={{ color: 'var(--text-2)' }}>
            Tap a day to view or edit. Only your primary daily mood log is shown — entry moods never affect this.
          </p>
        </div>
      )}

      {view === 'year' && (
        <div className="hd-card p-4">
          <h2 className="font-bold mb-3" style={{ color: 'var(--text)' }}>
            Emotion frequency — all time
          </h2>
          <div className="space-y-2">
            {emotionFrequency.map(([label, count]) => {
              const max = emotionFrequency[0][1] || 1;
              const color = MOOD_COLORS[label] ?? 'var(--accent)';
              return (
                <div key={label} className="flex items-center gap-2">
                  <span className="w-28 text-sm truncate" style={{ color: 'var(--text)' }}>{label}</span>
                  <div className="flex-1 h-5 rounded-full overflow-hidden" style={{ background: 'var(--surface-2)' }}>
                    <div className="h-full rounded-full" style={{ width: `${(count / max) * 100}%`, background: color }} />
                  </div>
                  <span className="w-8 text-right text-sm font-bold" style={{ color: 'var(--text-2)' }}>{count}</span>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {view === 'week' && (
        <div className="hd-card p-4">
          <h2 className="font-bold mb-3" style={{ color: 'var(--text)' }}>
            Week of {selectedDate}
          </h2>
          <div className="grid grid-cols-7 gap-1.5">
            {(() => {
              const base = new Date(selectedDate + 'T00:00:00');
              const dow = (base.getDay() + 6) % 7; // Monday=0
              base.setDate(base.getDate() - dow);
              return Array.from({ length: 7 }, (_, i) => {
                const d = iso(base);
                base.setDate(base.getDate() + 1);
                const log = logs.find((l) => l.date === d);
                const top = log?.moods?.slice().sort((a, b) => b.intensity - a.intensity)[0];
                return (
                  <button
                    key={d}
                    onClick={() => { setView('day'); setSelectedDate(d); refetchLog(d).then((l) => setDraft(l?.moods ?? [])); }}
                    className="rounded-lg border p-2 text-xs flex flex-col items-center gap-1"
                    style={{ background: top ? top.color + '26' : 'var(--surface-2)', borderColor: top ? top.color : 'var(--border)' }}
                  >
                    <span style={{ color: 'var(--text-2)' }}>{d.slice(8)}</span>
                    {top ? (
                      <>
                        <MoodIcon name={MOOD_ICONS[top.label] ?? 'smile'} className="w-4 h-4" />
                        <span className="truncate w-full text-center" style={{ color: top.color }}>{top.label}</span>
                      </>
                    ) : (
                      <span style={{ color: 'var(--text-2)' }}>—</span>
                    )}
                  </button>
                );
              });
            })()}
          </div>
        </div>
      )}
    </div>
  );
}
