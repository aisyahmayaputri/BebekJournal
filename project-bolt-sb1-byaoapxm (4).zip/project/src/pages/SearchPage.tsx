import { useEffect, useMemo, useState } from 'react';
import { ArrowLeft, Loader2, Search } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { dataApi } from '@/lib/data';
import { EntryCard } from '@/pages/LibraryPage';
import type { Entry, Tag } from '@/lib/types';

export default function SearchPage() {
  const nav = useNavigate();
  const [entries, setEntries] = useState<Entry[]>([]);
  const [tags, setTags] = useState<Tag[]>([]);
  const [loading, setLoading] = useState(true);
  const [q, setQ] = useState('');

  useEffect(() => {
    (async () => {
      try {
        const [es, tg] = await Promise.all([dataApi.listEntries(), dataApi.listTags()]);
        setEntries(es);
        setTags(tg);
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  const results = useMemo(() => {
    const s = q.trim().toLowerCase();
    if (!s) return [];
    return entries.filter((e) => {
      const hay = [
        e.title,
        e.content,
        e.blocks.book?.bookTitle,
        e.blocks.book?.author,
        e.blocks.movie?.movieTitle,
        e.blocks.hangout?.placeName,
      ]
        .filter(Boolean)
        .join(' ')
        .toLowerCase();
      return hay.includes(s);
    });
  }, [entries, q]);

  const tagMatches = useMemo(() => {
    const s = q.trim().toLowerCase();
    if (!s) return [];
    return tags.filter((t) => t.name.toLowerCase().includes(s));
  }, [tags, q]);

  if (loading) {
    return (
      <div className="flex justify-center py-20">
        <Loader2 className="w-8 h-8 animate-spin" style={{ color: 'var(--accent)' }} />
      </div>
    );
  }

  return (
    <div className="space-y-5 fade-up">
      <div className="flex items-center justify-between">
        <button className="hd-btn !p-2" onClick={() => nav('/')} aria-label="Back">
          <ArrowLeft className="w-5 h-5" />
        </button>
        <h1 className="text-2xl font-bold" style={{ color: 'var(--text)' }}>Search</h1>
        <span className="w-10" />
      </div>

      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4" style={{ color: 'var(--text-2)' }} />
        <input
          className="hd-input !pl-9"
          placeholder="Search titles, reviews, places, quotes…"
          value={q}
          onChange={(e) => setQ(e.target.value)}
          autoFocus
        />
      </div>

      {tagMatches.length > 0 && (
        <div className="flex flex-wrap gap-1.5">
          {tagMatches.map((t) => (
            <span key={t.id} className="text-xs px-2.5 py-1 rounded-full" style={{ background: t.chip_bg, color: t.chip_text }}>
              #{t.name}
            </span>
          ))}
        </div>
      )}

      {q.trim() && results.length === 0 ? (
        <div className="hd-card p-10 text-center">
          <p style={{ color: 'var(--text-2)' }}>No matches for "{q}".</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {results.map((e) => (
            <EntryCard key={e.id} entry={e} tags={[]} onClick={() => nav(`/entry/${e.id}`)} />
          ))}
        </div>
      )}
    </div>
  );
}
