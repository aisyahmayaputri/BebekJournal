import { useEffect, useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  BookOpen, Image, CalendarDays, Heart, Folder, Search, Settings2,
  ChartNoAxesCombined, Bookmark, Star, MapPin, Loader2,
} from 'lucide-react';
import { useAuth } from '@/lib/auth';
import { useI18n } from '@/lib/i18n';
import { usePrefs } from '@/lib/prefs';
import { dataApi } from '@/lib/data';
import FabMenu from '@/components/FabMenu';
import type { Entry, MoodLog, CalEvent, MoodDef } from '@/lib/types';
import { MOOD_ICONS } from '@/lib/types';
import {
  Smile, Coffee, PartyPopper, HeartHandshake, Sun, Flower2, Camera,
  CloudRain, Cloud, Flame, Zap, Moon, BatteryLow, Waves, Quote,
} from 'lucide-react';

const MOOD_ICON_MAP: Record<string, React.ComponentType<{ className?: string }>> = {
  smile: Smile, coffee: Coffee, 'party-popper': PartyPopper, heart: Heart,
  'heart-handshake': HeartHandshake, sun: Sun, flower: Flower2, camera: Camera,
  'cloud-rain': CloudRain, cloud: Cloud, flame: Flame, zap: Zap, moon: Moon,
  'battery-low': BatteryLow, waves: Waves,
};

export function MoodIcon({ name, className }: { name: string; className?: string }) {
  const C = MOOD_ICON_MAP[name] ?? Smile;
  return <C className={className} />;
}

function greetingFor(hour: number): string {
  if (hour < 12) return 'goodMorning';
  if (hour < 18) return 'goodAfternoon';
  return 'goodEvening';
}

const GREETING_LINES = ['greetingLine1', 'greetingLine2', 'greetingLine3', 'greetingLine4'] as const;

export default function HomePage() {
  const { user, profile } = useAuth();
  const { t } = useI18n();
  const { prefs } = usePrefs();
  const nav = useNavigate();
  const [entries, setEntries] = useState<Entry[]>([]);
  const [todayLog, setTodayLog] = useState<MoodLog | null>(null);
  const [moodDefs, setMoodDefs] = useState<MoodDef[]>([]);
  const [events, setEvents] = useState<CalEvent[]>([]);
  const [loading, setLoading] = useState(true);
  const [greetIdx, setGreetIdx] = useState(() => new Date().getDate() % GREETING_LINES.length);

  // remember scroll position across navigation and dialogs
  useEffect(() => {
    const saved = sessionStorage.getItem('db_home_scroll');
    if (saved) window.scrollTo(0, parseInt(saved, 10) || 0);
    const onScroll = () => sessionStorage.setItem('db_home_scroll', String(window.scrollY));
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => {
      window.removeEventListener('scroll', onScroll);
      onScroll();
    };
  }, []);

  const today = new Date().toISOString().slice(0, 10);
  const hour = new Date().getHours();

  useEffect(() => {
    let alive = true;
    (async () => {
      try {
        const [e, logs, moods, evs] = await Promise.all([
          dataApi.listEntries(),
          dataApi.listMoodLogs(today, today),
          dataApi.listMoods(),
          dataApi.listEvents(today, today),
        ]);
        if (!alive) return;
        setEntries(e);
        setTodayLog(logs[0] ?? null);
        setMoodDefs(moods);
        setEvents(evs);
      } catch {
        // keep prior data; failed fetch is not empty data
      } finally {
        if (alive) setLoading(false);
      }
    })();
    return () => {
      alive = false;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user?.id, today]);

  const bookOfYear = useMemo(() => {
    const year = String(new Date().getFullYear());
    const books = entries.filter(
      (e) => e.type === 'book' && (e.date ?? '').startsWith(year) && (e.blocks.book?.rating ?? 0) > 0
    );
    if (!books.length) return null;
    return [...books].sort(
      (a, b) => (b.blocks.book?.rating ?? 0) - (a.blocks.book?.rating ?? 0) ||
        (a.title || '').localeCompare(b.title || '')
    )[0];
  }, [entries]);

  const movieOfYear = useMemo(() => {
    const year = String(new Date().getFullYear());
    const movies = entries.filter(
      (e) => e.type === 'movie' && (e.date ?? '').startsWith(year) && (e.blocks.movie?.rating ?? 0) > 0
    );
    if (!movies.length) return null;
    return [...movies].sort(
      (a, b) => (b.blocks.movie?.rating ?? 0) - (a.blocks.movie?.rating ?? 0) ||
        (a.title || '').localeCompare(b.title || '')
    )[0];
  }, [entries]);

  const topPlaces = useMemo(() => {
    const counts = new Map<string, { name: string; count: number; photos: string[] }>();
    for (const e of entries) {
      if (e.type !== 'hangout') continue;
      const raw = (e.blocks.hangout?.placeName ?? '').trim();
      if (!raw) continue;
      const key = raw.toLowerCase().replace(/[^a-z0-9 ]/g, '').replace(/\s+/g, ' ');
      const cur = counts.get(key) ?? { name: raw, count: 0, photos: [] };
      cur.count += 1;
      const photos = e.blocks.hangout?.photos ?? [];
      if (photos[0]) cur.photos.push(photos[0].url);
      counts.set(key, cur);
    }
    return [...counts.values()].sort((a, b) => b.count - a.count).slice(0, 3);
  }, [entries]);

  const pinned = entries.filter((e) => e.pinned_home).slice(0, 4);

  const todayEvents = events;

  if (loading) {
    return (
      <div className="min-h-[60vh] flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin" style={{ color: 'var(--accent)' }} />
      </div>
    );
  }

  return (
    <div className="space-y-6 fade-up">
      {/* top header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <button className="hd-btn !p-2" onClick={() => nav('/library')} aria-label="All Journals" title="All Journals">
            <BookOpen className="w-5 h-5" />
          </button>
          <button className="hd-btn !p-2" onClick={() => nav('/moods')} aria-label="Mood Tracker" title="Mood Tracker">
            <Heart className="w-5 h-5" />
          </button>
          <button className="hd-btn !p-2" onClick={() => nav('/settings')} aria-label="Settings" title="Settings">
            <Settings2 className="w-5 h-5" />
          </button>
          <button className="hd-btn !p-2" onClick={() => nav('/search')} aria-label="Search" title="Search">
            <Search className="w-5 h-5" />
          </button>
        </div>
        <span
          className="font-bold text-lg select-none springy cursor-default"
          style={{ color: 'var(--text-2)' }}
          role="presentation"
        >
          Diary Bebek
        </span>
      </div>

      {/* greeting */}
      <div className="hd-card p-6" style={{ background: 'var(--surface)' }}>
        <h1 className="text-3xl font-bold" style={{ color: 'var(--text)' }}>
          {t(greetingFor(hour))}, {profile?.display_name ?? 'friend'}!
        </h1>
        <p style={{ color: 'var(--text-2)' }}>{t(GREETING_LINES[greetIdx])}</p>
      </div>

      {/* mood bubble */}
      <div className="hd-card p-5">
        <div className="flex items-center justify-between mb-3">
          <h2 className="text-lg font-bold flex items-center gap-2" style={{ color: 'var(--text)' }}>
            <Heart className="w-5 h-5" style={{ color: 'var(--accent)' }} /> {t('howAreYouFeeling')}
          </h2>
          <button className="hd-btn text-sm" onClick={() => nav('/moods')}>
            {t('moodTracker')}
          </button>
        </div>
        {todayLog && todayLog.moods.length > 0 ? (
          <div className="flex flex-wrap gap-2">
            {todayLog.moods.map((m) => (
              <span
                key={m.moodId}
                className="inline-flex items-center gap-1 px-3 py-1 rounded-full text-sm font-semibold"
                style={{ background: m.color + '22', color: m.color, border: `1.5px solid ${m.color}` }}
              >
                <MoodIcon name={MOOD_ICONS[m.label] ?? 'smile'} className="w-4 h-4" />
                {m.label} · {m.intensity}
              </span>
            ))}
          </div>
        ) : (
          <p className="text-sm" style={{ color: 'var(--text-2)' }}>
            {t('noMoodYet')}
          </p>
        )}
      </div>

      {/* quick access */}
      <section>
        <h2 className="doodle-underline text-lg font-bold mb-4" style={{ color: 'var(--text)' }}>
          {t('quickAccess')}
        </h2>
        <div className="grid grid-cols-2 gap-4">
          <QuickCard icon={<Image className="w-7 h-7" />} label={t('gallery')} onClick={() => nav('/gallery')} />
          <QuickCard icon={<BookOpen className="w-7 h-7" />} label={t('library')} onClick={() => nav('/library')} />
          <QuickCard icon={<MapPin className="w-7 h-7" />} label={t('memories')} onClick={() => nav('/memories')} />
          <QuickCard icon={<ChartNoAxesCombined className="w-7 h-7" />} label={t('statistics')} onClick={() => nav('/stats')} />
        </div>
      </section>

      {/* book of the year */}
      <div className="hd-card p-5">
        <div className="flex items-center justify-between mb-3">
          <h2 className="text-lg font-bold flex items-center gap-2" style={{ color: 'var(--text)' }}>
            <BookOpen className="w-5 h-5" style={{ color: 'var(--accent)' }} /> {t('bookOfTheYear')}
          </h2>
          <button className="hd-btn text-sm" onClick={() => nav('/library?type=book')}>
            {t('allBooks')}
          </button>
        </div>
        {bookOfYear ? (
          <BookOrMovieCard
            title={bookOfYear.blocks.book?.bookTitle ?? bookOfYear.title}
            subtitle={bookOfYear.blocks.book?.author}
            rating={bookOfYear.blocks.book?.rating ?? 0}
            cover={bookOfYear.blocks.book?.coverUrl}
            onClick={() => nav(`/entry/${bookOfYear.id}`)}
          />
        ) : (
          <EmptyMini text={t('noBooksYet')} onCreate={() => nav('/editor/new?type=book')} />
        )}
      </div>

      {/* movie of the year */}
      <div className="hd-card p-5">
        <div className="flex items-center justify-between mb-3">
          <h2 className="text-lg font-bold flex items-center gap-2" style={{ color: 'var(--text)' }}>
            <Star className="w-5 h-5" style={{ color: 'var(--accent)' }} /> {t('movieOfTheYear')}
          </h2>
          <button className="hd-btn text-sm" onClick={() => nav('/library?type=movie')}>
            {t('allMovies')}
          </button>
        </div>
        {movieOfYear ? (
          <BookOrMovieCard
            title={movieOfYear.blocks.movie?.movieTitle ?? movieOfYear.title}
            subtitle={movieOfYear.blocks.movie?.genre}
            rating={movieOfYear.blocks.movie?.rating ?? 0}
            cover={movieOfYear.blocks.movie?.coverUrl}
            onClick={() => nav(`/entry/${movieOfYear.id}`)}
          />
        ) : (
          <EmptyMini text={t('noMoviesYet')} onCreate={() => nav('/editor/new?type=movie')} />
        )}
      </div>

      {/* pinned */}
      {pinned.length > 0 && (
        <section>
          <h2 className="text-lg font-bold mb-3 flex items-center gap-2" style={{ color: 'var(--text)' }}>
            <Bookmark className="w-5 h-5" style={{ color: 'var(--accent)' }} /> Pinned
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {pinned.map((e) => (
              <button
                key={e.id}
                className="hd-card hd-card-hover p-4 text-left"
                onClick={() => nav(`/entry/${e.id}`)}
              >
                <p className="font-bold truncate" style={{ color: 'var(--text)' }}>
                  {e.title || 'Untitled'}
                </p>
                <p className="text-sm" style={{ color: 'var(--text-2)' }}>
                  {e.date}
                </p>
              </button>
            ))}
          </div>
        </section>
      )}

      {/* frequently visited places */}
      <div className="hd-card p-5">
        <h2 className="text-lg font-bold mb-3 flex items-center gap-2" style={{ color: 'var(--text)' }}>
          <MapPin className="w-5 h-5" style={{ color: 'var(--accent)' }} /> {t('frequentlyVisited')}
        </h2>
        {topPlaces.length > 0 ? (
          <div className="flex flex-wrap gap-3">
            {topPlaces.map((p) => (
              <button
                key={p.name}
                onClick={() => nav('/memories')}
                className="hd-btn text-sm"
              >
                <MapPin className="w-4 h-4" /> {p.name} · {p.count} {t('visits')}
              </button>
            ))}
          </div>
        ) : (
          <p className="text-sm" style={{ color: 'var(--text-2)' }}>
            {t('noPlacesYet')}
          </p>
        )}
      </div>

      {/* today events preview */}
      <div className="hd-card p-5">
        <div className="flex items-center justify-between mb-3">
          <h2 className="text-lg font-bold flex items-center gap-2" style={{ color: 'var(--text)' }}>
            <CalendarDays className="w-5 h-5" style={{ color: 'var(--accent)' }} /> {t('today')}
          </h2>
          <button className="hd-btn text-sm" onClick={() => nav('/calendar')}>
            Calendar
          </button>
        </div>
        {todayEvents.length > 0 ? (
          <div className="space-y-2">
            {todayEvents.map((ev) => (
              <div key={ev.id} className="flex items-center gap-2">
                <span className="w-3 h-3 rounded-full" style={{ background: ev.color }} />
                <span style={{ color: 'var(--text)' }}>{ev.name}</span>
              </div>
            ))}
          </div>
        ) : (
          <p className="text-sm" style={{ color: 'var(--text-2)' }}>
            No events today.
          </p>
        )}
      </div>

      {/* branched create FAB (New Entry / New Tag / New Folder) */}
      <div className="fab-mount"><FabMenu /></div>
    </div>
  );
}

function QuickCard({ icon, label, onClick }: { icon: React.ReactNode; label: string; onClick: () => void }) {
  return (
    <button onClick={onClick} className="hd-card hd-card-hover p-5 flex flex-col items-center gap-2 springy wiggle-hover card-pop">
      <span className="floaty" style={{ color: 'var(--accent)' }}>{icon}</span>
      <span className="font-semibold" style={{ color: 'var(--text)' }}>
        {label}
      </span>
    </button>
  );
}

function BookOrMovieCard({
  title,
  subtitle,
  rating,
  cover,
  onClick,
}: {
  title: string;
  subtitle?: string;
  rating: number;
  cover?: string;
  onClick: () => void;
}) {
  return (
    <button onClick={onClick} className="flex gap-4 items-center text-left w-full hd-card-hover rounded-xl p-2">
      {cover ? (
        <img src={cover} alt={title} className="w-16 h-24 object-cover rounded-lg hd-border" />
      ) : (
        <div className="w-16 h-24 rounded-lg hd-border flex items-center justify-center" style={{ background: 'var(--surface-2)' }}>
          <Quote className="w-6 h-6" style={{ color: 'var(--outline)' }} />
        </div>
      )}
      <div className="min-w-0">
        <p className="font-bold truncate" style={{ color: 'var(--text)' }}>
          {title}
        </p>
        {subtitle && (
          <p className="text-sm truncate" style={{ color: 'var(--text-2)' }}>
            {subtitle}
          </p>
        )}
        <div className="flex gap-0.5 mt-1">
          {Array.from({ length: 5 }).map((_, i) => (
            <Star
              key={i}
              className="w-4 h-4"
              style={{ color: i < Math.round(rating) ? 'var(--accent)' : 'var(--border)' }}
              fill={i < Math.round(rating) ? 'var(--accent)' : 'none'}
            />
          ))}
        </div>
      </div>
    </button>
  );
}

function EmptyMini({ text, onCreate }: { text: string; onCreate: () => void }) {
  const { t } = useI18n();
  return (
    <div className="text-center py-3">
      <p className="text-sm mb-2" style={{ color: 'var(--text-2)' }}>
        {text}
      </p>
      <button className="hd-btn hd-btn-primary text-sm" onClick={onCreate}>
        + {t('newEntry')}
      </button>
    </div>
  );
}
