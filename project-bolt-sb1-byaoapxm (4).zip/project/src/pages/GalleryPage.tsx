import { useEffect, useMemo, useState } from 'react';
import { ArrowLeft, Loader2, Image as ImageIcon, AlertCircle } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { dataApi } from '@/lib/data';
import type { Entry } from '@/lib/types';

export default function GalleryPage() {
  const nav = useNavigate();
  const [entries, setEntries] = useState<Entry[]>([]);
  const [urls, setUrls] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [preview, setPreview] = useState<{ url: string; entry: Entry } | null>(null);

  useEffect(() => {
    let alive = true;
    (async () => {
      try {
        const es = await dataApi.listEntries();
        if (!alive) return;
        setEntries(es);
        // collect all stored media paths
        const pathMap = new Map<string, Entry>();
        for (const e of es) {
          const media = e.blocks.media ?? [];
          const photos = e.blocks.hangout?.photos ?? [];
          for (const m of [...media, ...photos]) {
            if (m.kind === 'image' && !m.external) {
              if (!pathMap.has(m.url)) pathMap.set(m.url, e);
            }
          }
          const covers = [e.blocks.movie?.coverUrl, e.blocks.book?.coverUrl];
          for (const c of covers) if (c && !c.startsWith('blob:') && !c.startsWith('http')) pathMap.set(c, e);
        }
        // sign URLs in batches
        const next: Record<string, string> = {};
        const paths = [...pathMap.keys()];
        for (let i = 0; i < paths.length; i += 20) {
          const batch = paths.slice(i, i + 20);
          const results = await Promise.all(
            batch.map(async (p) => {
              try {
                return [p, await dataApi.createSignedUrl(p)] as const;
              } catch {
                return null;
              }
            })
          );
          for (const r of results) if (r) next[r[0]] = r[1];
        }
        if (alive) setUrls(next);
      } catch (e) {
        if (alive) setError(e instanceof Error ? e.message : 'Failed to load gallery');
      } finally {
        if (alive) setLoading(false);
      }
    })();
    return () => {
      alive = false;
    };
  }, []);

  const images = useMemo(() => {
    const out: { path: string; entry: Entry }[] = [];
    for (const e of entries) {
      const media = (e.blocks.media ?? []).filter((m) => m.kind === 'image');
      const photos = e.blocks.hangout?.photos ?? [];
      for (const m of [...media, ...photos]) {
        if (m.kind === 'image') out.push({ path: m.url, entry: e });
      }
    }
    return out;
  }, [entries]);

  if (loading) {
    return (
      <div className="flex justify-center py-20">
        <Loader2 className="w-8 h-8 animate-spin" style={{ color: 'var(--accent)' }} />
      </div>
    );
  }

  return (
    <div className="space-y-5 fade-up">
      <div className="flex items-center justify-between">
        <button className="hd-btn !p-2" onClick={() => nav('/')} aria-label="Back">
          <ArrowLeft className="w-5 h-5" />
        </button>
        <h1 className="text-2xl font-bold flex items-center gap-2" style={{ color: 'var(--text)' }}>
          <ImageIcon className="w-6 h-6" style={{ color: 'var(--accent)' }} /> Gallery
        </h1>
        <span className="w-10" />
      </div>

      {error && (
        <div className="hd-card p-4 flex items-center gap-2">
          <AlertCircle className="w-5 h-5" style={{ color: 'var(--error)' }} />
          <p style={{ color: 'var(--error)' }}>{error}</p>
        </div>
      )}

      {images.length === 0 ? (
        <div className="hd-card p-10 text-center">
          <ImageIcon className="w-10 h-10 mx-auto mb-3" style={{ color: 'var(--outline)' }} />
          <p style={{ color: 'var(--text-2)' }}>
            No photos yet. Add photos from any entry's editor.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-3 sm:grid-cols-4 lg:grid-cols-6 gap-2">
          {images.map(({ path, entry }, i) => {
            const url = urls[path];
            return (
              <button
                key={`${path}-${i}`}
                className="aspect-square rounded-lg hd-border overflow-hidden hd-card-hover"
                onClick={() => url && setPreview({ url, entry })}
                title={entry.title || 'Untitled'}
              >
                {url ? (
                  <img src={url} alt={entry.title ?? ''} className="w-full h-full object-cover" loading="lazy" />
                ) : (
                  <div className="w-full h-full flex items-center justify-center" style={{ background: 'var(--surface-2)' }}>
                    <Loader2 className="w-4 h-4 animate-spin" style={{ color: 'var(--outline)' }} />
                  </div>
                )}
              </button>
            );
          })}
        </div>
      )}

      {preview && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4"
          style={{ background: 'rgba(0,0,0,0.75)' }}
          onClick={() => setPreview(null)}
        >
          <div className="max-w-2xl w-full" onClick={(e) => e.stopPropagation()}>
            <img src={preview.url} alt="" className="w-full rounded-xl" />
            <div className="mt-3 flex items-center justify-between gap-2">
              <p className="text-white text-sm truncate">{preview.entry.title || 'Untitled'} · {preview.entry.date}</p>
              <button className="hd-btn text-sm" onClick={() => nav(`/entry/${preview.entry.id}`)}>
                Open entry
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
