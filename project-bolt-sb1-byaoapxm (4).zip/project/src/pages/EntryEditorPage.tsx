import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { useNavigate, useParams, useSearchParams } from 'react-router-dom';
import {
  ArrowLeft, Eye, FolderPlus, Image as ImageIcon, Music, Palette, Pencil,
  Share2, FileDown, Star, Tag as TagIcon, Loader2, Check, AlertCircle, Lock, Unlock, Trash2,
  CalendarDays, Smile, X,
} from 'lucide-react';
import { dataApi } from '@/lib/data';
import { useAutosave } from '@/lib/useAutosave';
import { useI18n } from '@/lib/i18n';
import { DEFAULT_ENTRY_THEME, type EntryTheme } from '@/lib/themes';
import { ENTRY_FONTS } from '@/lib/fonts';
import FormatToolbar, { execFormat } from '@/components/FormatToolbar';
import DrawingCanvas, { DrawingControls, type DrawTool } from '@/components/DrawingCanvas';
import type { Entry, EntryType, MediaItem, Tag, Folder, RatingConfig, DrawingLayer, BookBlocks } from '@/lib/types';
import { MOOD_COLORS } from '@/lib/types';

const MAX_IMAGE_BYTES = 15 * 1024 * 1024;

function formatDateLabel(iso: string): string {
  const [y, m, d] = iso.split('-').map(Number);
  if (!y || !m || !d) return iso;
  return new Date(y, m - 1, d).toLocaleDateString(undefined, {
    weekday: 'short', year: 'numeric', month: 'short', day: 'numeric',
  });
}

interface TypeFieldsProps {
  type: EntryType;
  entry: Entry;
  onBlocks: (patch: Record<string, unknown>) => void;
  onUploadImage: (file: File, slot: 'cover' | 'gallery' | 'media') => Promise<void>;
}

function BookFields({
  entry, onBlocks, onUploadImage, patchEntry, accent, triedSubmit,
}: {
  entry: Entry;
  onBlocks: (patch: Record<string, unknown>) => void;
  onUploadImage: (file: File, slot: 'cover' | 'gallery' | 'media') => Promise<void>;
  patchEntry: (patch: Partial<Entry>) => void;
  accent: string;
  triedSubmit: boolean;
}) {
  const [uploading, setUploading] = useState(false);
  const b = entry.blocks.book ?? {};
  const quotes = b.quotes ?? [];
  const setBook = (patch: Partial<BookBlocks>) => onBlocks({ book: { ...b, ...patch } });
  const required = <span style={{ color: 'var(--error)' }}>*</span>;
  const showMissing = (ok: boolean) => triedSubmit && !ok;

  return (
    <div className="space-y-4 mb-4">
      {/* top section: cover + title / rating / recommend */}
      <div className="grid grid-cols-1 sm:grid-cols-[170px_1fr] gap-4">
        <div>
          <p className="text-sm font-semibold mb-1" style={{ color: 'var(--text-2)' }}>
            Book Cover {required}
          </p>
          <label
            className="block cursor-pointer hd-border overflow-hidden transition-transform hover:scale-[1.02]"
            style={{
              aspectRatio: '3/4',
              background: 'var(--surface-2)',
              outline: showMissing(!b.coverUrl) ? '2px solid var(--error)' : undefined,
              outlineOffset: 2,
            }}
            title="Upload book cover"
          >
            {b.coverUrl ? (
              <img src={b.coverUrl} alt="Book cover" className="w-full h-full object-cover" />
            ) : (
              <span className="w-full h-full flex flex-col items-center justify-center gap-2" style={{ color: 'var(--outline)' }}>
                <ImageIcon className="w-8 h-8" />
                <span className="text-xs font-semibold">Add cover</span>
              </span>
            )}
            <input
              type="file"
              accept="image/*"
              className="hidden"
              onChange={async (e) => {
                const f = e.target.files?.[0];
                if (f) { setUploading(true); await onUploadImage(f, 'cover'); setUploading(false); }
              }}
            />
          </label>
          {uploading && (
            <p className="text-xs mt-1 flex items-center gap-1" style={{ color: 'var(--text-2)' }}>
              <Loader2 className="w-3 h-3 animate-spin" /> Uploading…
            </p>
          )}
        </div>
        <div className="space-y-3">
          <div>
            <p className="text-sm font-semibold mb-1" style={{ color: 'var(--text-2)' }}>
              Title {required}
            </p>
            <input
              className="hd-input"
              placeholder="Book title…"
              value={entry.title}
              style={{ borderColor: showMissing(!entry.title.trim()) ? 'var(--error)' : undefined }}
              onChange={(e) => patchEntry({ title: e.target.value })}
            />
          </div>
          <div>
            <p className="text-sm font-semibold mb-1" style={{ color: 'var(--text-2)' }}>
              Rating {required}
            </p>
            <div className="flex items-center gap-1">
              {Array.from({ length: 5 }).map((_, i) => (
                <button
                  key={i}
                  type="button"
                  onClick={() => setBook({ rating: i + 1 })}
                  aria-label={`Rate ${i + 1} stars`}
                  className="transition-transform hover:scale-110"
                >
                  <Star
                    style={{
                      width: 24,
                      height: 24,
                      color: i < (b.rating ?? 0) ? accent : 'var(--border)',
                      fill: i < (b.rating ?? 0) ? accent : 'none',
                    }}
                  />
                </button>
              ))}
              {showMissing(!(b.rating ?? 0)) && (
                <span className="text-xs ml-2" style={{ color: 'var(--error)' }}>Required</span>
              )}
            </div>
          </div>
          <div>
            <p className="text-sm font-semibold mb-1" style={{ color: 'var(--text-2)' }}>
              Recommend? {required}
            </p>
            <div className="flex gap-2">
              {[true, false].map((val) => {
                const active = b.recommended === val;
                return (
                  <button
                    key={String(val)}
                    type="button"
                    onClick={() => setBook({ recommended: val })}
                    aria-pressed={active}
                    className="px-5 py-1.5 rounded-full border-2 text-sm font-semibold transition-colors"
                    style={active
                      ? { background: accent, borderColor: accent, color: 'var(--accent-contrast)' }
                      : { background: 'var(--surface)', borderColor: 'var(--border)', color: 'var(--text-2)' }}
                  >
                    {val ? 'Yes' : 'No'}
                  </button>
                );
              })}
              {showMissing(b.recommended === undefined || b.recommended === null) && (
                <span className="text-xs self-center" style={{ color: 'var(--error)' }}>Required</span>
              )}
            </div>
          </div>
          <input
            type="date"
            className="hd-input !w-auto text-sm"
            value={b.readingDate ?? ''}
            onChange={(e) => setBook({ readingDate: e.target.value })}
            aria-label="Reading date"
          />
        </div>
      </div>

      {/* middle section: favorite quotes */}
      <div>
        <p className="text-sm font-semibold mb-2" style={{ color: 'var(--text-2)' }}>Favorite quotes</p>
        {quotes.map((q, i) => (
          <div key={i} className="hd-card !rounded-xl p-3 mb-3">
            <div className="relative">
              <span
                aria-hidden
                className="absolute -top-1 left-1 text-3xl leading-none select-none pointer-events-none"
                style={{ color: accent, fontFamily: 'Georgia, serif' }}
              >
                &ldquo;
              </span>
              <textarea
                className="hd-input !border-none !bg-transparent !p-0 pl-7 resize-y"
                rows={2}
                placeholder="Write a quote…"
                value={q.text}
                style={{ fontStyle: 'italic' }}
                onChange={(e) => {
                  const nq = [...quotes]; nq[i] = { ...q, text: e.target.value }; setBook({ quotes: nq });
                }}
              />
            </div>
            <div className="flex gap-2 mt-2 items-center flex-wrap">
              <input
                className="hd-input !w-20 text-sm"
                type="number"
                min={1}
                placeholder="Page"
                value={q.page ?? ''}
                onChange={(e) => {
                  const nq = [...quotes]; nq[i] = { ...q, page: e.target.value === '' ? undefined : Number(e.target.value) }; setBook({ quotes: nq });
                }}
              />
              <input
                className="hd-input !w-40 text-sm flex-1"
                placeholder="- Alexa"
                value={q.name ?? ''}
                onChange={(e) => {
                  const nq = [...quotes]; nq[i] = { ...q, name: e.target.value }; setBook({ quotes: nq });
                }}
              />
              <button
                className="hd-btn !p-2 ml-auto"
                onClick={() => setBook({ quotes: quotes.filter((_, j) => j !== i) })}
                aria-label="Remove quote"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          </div>
        ))}
        <button className="hd-btn text-sm" onClick={() => setBook({ quotes: [...quotes, { text: '' }] })}>
          + Add Quote
        </button>
      </div>
    </div>
  );
}

function TypeFields({ type, entry, onBlocks, onUploadImage }: TypeFieldsProps) {
  const [uploading, setUploading] = useState(false);
  if (type === 'diary') return null;

  if (type === 'movie') {
    const m = entry.blocks.movie ?? {};
    return (
      <div className="hd-card p-4 space-y-3 mb-4">
        <h3 className="font-bold" style={{ color: 'var(--text)' }}>Movie Details</h3>
        <input className="hd-input" placeholder="Movie title" value={m.movieTitle ?? ''} onChange={(e) => onBlocks({ movie: { ...m, movieTitle: e.target.value } })} />
        <div className="flex gap-2 items-center">
          {m.coverUrl && <img src={m.coverUrl} alt="cover" className="w-12 h-16 object-cover rounded hd-border" />}
          <label className="hd-btn text-sm cursor-pointer">
            <ImageIcon className="w-4 h-4" /> Cover
            <input type="file" accept="image/*" className="hidden" onChange={async (e) => {
              const f = e.target.files?.[0];
              if (f) { setUploading(true); await onUploadImage(f, 'cover'); setUploading(false); }
            }} />
          </label>
          {uploading && <Loader2 className="w-4 h-4 animate-spin" />}
        </div>
        <div className="flex gap-3 items-center flex-wrap">
          <label className="text-sm flex items-center gap-1" style={{ color: 'var(--text-2)' }}>
            Rating
            <input type="number" min={0} max={5} step={0.5} className="hd-input !w-16" value={m.rating ?? 0} onChange={(e) => onBlocks({ movie: { ...m, rating: Number(e.target.value) } })} />
          </label>
          <label className="text-sm flex items-center gap-1" style={{ color: 'var(--text-2)' }}>
            Rewatches
            <input type="number" min={0} className="hd-input !w-16" value={m.rewatchCount ?? 0} onChange={(e) => onBlocks({ movie: { ...m, rewatchCount: Number(e.target.value), rewatched: Number(e.target.value) > 0 } })} />
          </label>
          <input type="date" className="hd-input !w-auto text-sm" value={m.watchDate ?? ''} onChange={(e) => onBlocks({ movie: { ...m, watchDate: e.target.value } })} aria-label="Watch date" />
          <input className="hd-input !w-auto text-sm flex-1" placeholder="Genre" value={m.genre ?? ''} onChange={(e) => onBlocks({ movie: { ...m, genre: e.target.value } })} />
        </div>
        <textarea className="hd-input" rows={2} placeholder="Private comments" value={m.comment ?? ''} onChange={(e) => onBlocks({ movie: { ...m, comment: e.target.value } })} />
      </div>
    );
  }

  // hangout
  const h = entry.blocks.hangout ?? {};
  const photos = h.photos ?? [];
  return (
    <div className="hd-card p-4 space-y-3 mb-4">
      <h3 className="font-bold" style={{ color: 'var(--text)' }}>Hangout Details</h3>
      <input className="hd-input" placeholder="Place name" value={h.placeName ?? ''} onChange={(e) => onBlocks({ hangout: { ...h, placeName: e.target.value } })} />
      <div className="flex gap-3 items-center flex-wrap">
        <label className="text-sm flex items-center gap-1" style={{ color: 'var(--text-2)' }}>
          Place rating
          <input type="number" min={0} max={5} step={0.5} className="hd-input !w-16" value={h.placeRating ?? 0} onChange={(e) => onBlocks({ hangout: { ...h, placeRating: Number(e.target.value) } })} />
        </label>
        <input type="date" className="hd-input !w-auto text-sm" value={h.visitDate ?? ''} onChange={(e) => onBlocks({ hangout: { ...h, visitDate: e.target.value } })} aria-label="Visit date" />
        <input className="hd-input !w-auto text-sm flex-1" placeholder="Location (optional)" value={h.location ?? ''} onChange={(e) => onBlocks({ hangout: { ...h, location: e.target.value } })} />
      </div>
      <div>
        <p className="text-sm mb-1" style={{ color: 'var(--text-2)' }}>Photos (1–5, square)</p>
        <div className="flex gap-2 flex-wrap">
          {photos.map((p, i) => (
            <div key={p.id} className="relative w-20 h-20">
              <img src={p.url} alt="" className="w-20 h-20 object-cover rounded-lg hd-border" style={{ aspectRatio: '1/1' }} />
              <button
                className="absolute -top-2 -right-2 w-6 h-6 rounded-full flex items-center justify-center border"
                style={{ background: 'var(--error)', color: '#fff', borderColor: 'var(--border)' }}
                onClick={() => onBlocks({ hangout: { ...h, photos: photos.filter((_, j) => j !== i) } })}
                aria-label="Remove photo"
              >
                ×
              </button>
            </div>
          ))}
          {photos.length < 5 && (
            <label className="w-20 h-20 rounded-lg hd-border flex items-center justify-center cursor-pointer" style={{ background: 'var(--surface-2)' }}>
              <ImageIcon className="w-6 h-6" style={{ color: 'var(--outline)' }} />
              <input type="file" accept="image/*" className="hidden" onChange={async (e) => {
                const f = e.target.files?.[0];
                if (f) { setUploading(true); await onUploadImage(f, 'gallery'); setUploading(false); }
              }} />
            </label>
          )}
        </div>
      </div>
      <textarea className="hd-input" rows={2} placeholder="Notes about this place" value={h.description ?? ''} onChange={(e) => onBlocks({ hangout: { ...h, description: e.target.value } })} />
    </div>
  );
}

export default function EntryEditorPage() {
  const { id } = useParams();
  const [params] = useSearchParams();
  const nav = useNavigate();
  const { t } = useI18n();

  const isNew = !id;
  const initialType = (params.get('type') as EntryType) || 'diary';

  const [entry, setEntry] = useState<Entry | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [reviewMode, setReviewMode] = useState(false);
  const [drawMode, setDrawMode] = useState(false);
  const [showTheme, setShowTheme] = useState(false);
  const [showTagsPanel, setShowTagsPanel] = useState(false);
  const [allTags, setAllTags] = useState<Tag[]>([]);
  const [folders, setFolders] = useState<Folder[]>([]);
  const [entryTagIds, setEntryTagIds] = useState<string[]>([]);
  const [entryFolderIds, setEntryFolderIds] = useState<string[]>([]);
  const [uploadingMedia, setUploadingMedia] = useState(false);
  const [mediaError, setMediaError] = useState<string | null>(null);
  const [triedSubmit, setTriedSubmit] = useState(false);
  const [showRatingPanel, setShowRatingPanel] = useState(false);
  const [showEmojiPanel, setShowEmojiPanel] = useState(false);
  const richRef = useRef<HTMLDivElement>(null);

  // drawing state
  const [drawTool, setDrawTool] = useState<DrawTool>('pen');
  const [drawColor, setDrawColor] = useState('#49382E');
  const [drawWidth, setDrawWidth] = useState(3);
  const [drawOpacity, setDrawOpacity] = useState(1);
  const drawingHistory = useRef<DrawingLayer[][]>([]);
  const drawingFuture = useRef<DrawingLayer[][]>([]);

  const { state: saveState, queue, flushNow, lastError } = useAutosave(isNew ? null : id ?? null);

  // seed the editor's HTML once per entry — re-applying it on every keystroke
  // resets the caret to the start, which made typed text appear reversed.
  useEffect(() => {
    if (richRef.current && !reviewMode) richRef.current.innerHTML = entry?.content ?? '';
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [entry?.id, reviewMode]);

  // load or create
  const createGuarded = useRef(false);
  useEffect(() => {
    if (isNew) {
      // create the row, then move to its real route so autosave binds to the id.
      // nav must not depend on `alive`: StrictMode cancels the first effect run
      // right after this async completes, which previously skipped navigation
      // and left the user on /editor/new with an "Entry not found" error card.
      if (createGuarded.current) return;
      createGuarded.current = true;
      setLoading(true);
      (async () => {
        try {
          const created = await dataApi.createEntry({ type: initialType });
          nav(`/entry/${created.id}`, { replace: true });
        } catch (err) {
          createGuarded.current = false;
          setError(err instanceof Error ? err.message : 'Failed to create entry');
          setLoading(false);
        }
      })();
      return;
    }
    let alive = true;
    (async () => {
      try {
        const e = await dataApi.getEntry(id!);
        if (!alive) return;
        if (!e) {
          setError('Entry not found');
        } else {
          setEntry(e);
          const [tg, fd, et, ef] = await Promise.all([
            dataApi.listTags(),
            dataApi.listFolders(),
            dataApi.getEntryTagIds(e.id),
            dataApi.getEntryFolderIds(e.id),
          ]);
          if (!alive) return;
          setAllTags(tg);
          setFolders(fd);
          setEntryTagIds(et);
          setEntryFolderIds(ef);
        }
      } catch (err) {
        if (alive) setError(err instanceof Error ? err.message : 'Failed to load entry');
      } finally {
        if (alive) setLoading(false);
      }
    })();
    return () => {
      alive = false;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);

  const theme: EntryTheme = { ...DEFAULT_ENTRY_THEME, ...(entry?.blocks.theme ?? {}) };

  const patchEntry = useCallback(
    (patch: Partial<Entry>) => {
      setEntry((prev) => (prev ? { ...prev, ...patch } : prev));
      if (!isNew) queue(patch);
    },
    [isNew, queue]
  );

  const patchBlocks = useCallback(
    (patch: Record<string, unknown>) => {
      setEntry((prev) => {
        if (!prev) return prev;
        const next = { ...prev, blocks: { ...prev.blocks, ...patch } };
        if (!isNew) queue({ blocks: next.blocks });
        return next;
      });
    },
    [isNew, queue]
  );

  const onBlocksField = (patch: Record<string, unknown>) => {
    // used by TypeFields — merges into blocks
    patchBlocks(patch);
  };

  const onUploadImage = async (file: File, slot: 'cover' | 'gallery' | 'media') => {
    if (!entry) return;
    setMediaError(null);
    if (file.size > MAX_IMAGE_BYTES) {
      setMediaError('Image is larger than 15 MB. Please choose a smaller file.');
      return;
    }
    if (!file.type.startsWith('image/')) {
      setMediaError('Only image files are supported.');
      return;
    }
    try {
      setUploadingMedia(true);
      const { path } = await dataApi.uploadMedia(file, entry.id);
      const url = await dataApi.createSignedUrl(path);
      if (slot === 'cover') {
        if (entry.type === 'movie') {
          patchBlocks({ movie: { ...(entry.blocks.movie ?? {}), coverUrl: url } });
        } else if (entry.type === 'book') {
          patchBlocks({ book: { ...(entry.blocks.book ?? {}), coverUrl: url } });
        }
      } else if (entry.type === 'hangout') {
        const photos = [...(entry.blocks.hangout?.photos ?? []), { id: path, kind: 'image' as const, url: path }];
        patchBlocks({ hangout: { ...(entry.blocks.hangout ?? {}), photos } });
      } else {
        const media = [...(entry.blocks.media ?? []), { id: path, kind: 'image' as const, url: path }];
        patchBlocks({ media });
      }
    } catch (err) {
      setMediaError(err instanceof Error ? err.message : 'Upload failed');
    } finally {
      setUploadingMedia(false);
    }
  };

  const addAudio = async (file: File) => {
    if (!entry) return;
    try {
      setUploadingMedia(true);
      const { path } = await dataApi.uploadMedia(file, entry.id);
      const media = [...(entry.blocks.media ?? []), { id: path, kind: 'audio' as const, url: path }];
      patchBlocks({ media });
    } catch (err) {
      setMediaError(err instanceof Error ? err.message : 'Audio upload failed');
    } finally {
      setUploadingMedia(false);
    }
  };

  // resolve display URLs for stored paths
  const [mediaUrls, setMediaUrls] = useState<Record<string, string>>({});
  useEffect(() => {
    let alive = true;
    (async () => {
      const items: MediaItem[] = [
        ...(entry?.blocks.media ?? []),
        ...(entry?.blocks.hangout?.photos ?? []),
      ];
      const next: Record<string, string> = {};
      for (const m of items) {
        if (m.external) {
          next[m.url] = m.url;
        } else if (!mediaUrls[m.url]) {
          try {
            next[m.url] = await dataApi.createSignedUrl(m.url);
          } catch {
            // keep whatever we had; unavailable media shows as broken
          }
        }
      }
      if (alive && Object.keys(next).length) {
        setMediaUrls((prev) => ({ ...prev, ...next }));
      }
    })();
    return () => {
      alive = false;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [entry?.blocks.media, entry?.blocks.hangout?.photos]);

  // drawing history
  const setLayers = (layers: DrawingLayer[]) => {
    if (!entry) return;
    drawingHistory.current = [...drawingHistory.current.slice(-30), entry.blocks.drawing ?? []];
    drawingFuture.current = [];
    patchBlocks({ drawing: layers });
  };
  const undoDraw = () => {
    if (!entry) return;
    const hist = drawingHistory.current;
    if (!hist.length) return;
    const prev = hist[hist.length - 1];
    drawingHistory.current = hist.slice(0, -1);
    drawingFuture.current = [...drawingFuture.current, entry.blocks.drawing ?? []];
    patchBlocks({ drawing: prev });
  };
  const redoDraw = () => {
    if (!entry) return;
    const fut = drawingFuture.current;
    if (!fut.length) return;
    const next = fut[fut.length - 1];
    drawingFuture.current = fut.slice(0, -1);
    drawingHistory.current = [...drawingHistory.current, entry.blocks.drawing ?? []];
    patchBlocks({ drawing: next });
  };

  const insertDivider = (kind: 'line' | 'stars' | 'hearts') => {
    const el = document.getElementById('entry-rich-text');
    if (!el) return;
    const div = document.createElement('div');
    div.contentEditable = 'false';
    if (kind === 'line') div.innerHTML = '<hr/>';
    if (kind === 'stars') div.innerHTML = '<p style="text-align:center;color:var(--accent)">✶ ✶ ✶</p>';
    if (kind === 'hearts') div.innerHTML = '<p style="text-align:center;color:var(--accent)">♥ ♥ ♥</p>';
    el.appendChild(div);
  };

  const insertLink = (url: string, label: string) => {
    document.execCommand('createLink', false, url);
    // set label: find last anchor and replace text
    const el = document.getElementById('entry-rich-text');
    if (el) {
      const anchors = el.querySelectorAll('a');
      const last = anchors[anchors.length - 1];
      if (last && label) last.textContent = label;
    }
  };

  const share = async () => {
    if (!entry) return;
    const text = `${entry.title || 'My diary entry'}\n\n${entry.content.replace(/<[^>]+>/g, ' ')}`;
    if (navigator.share) {
      try {
        await navigator.share({ title: entry.title || 'Diary Bebek', text });
        return;
      } catch {
        /* user cancelled — fall through to clipboard */
      }
    }
    await navigator.clipboard.writeText(text);
    alert('Entry copied to clipboard');
  };

  const exportPdf = async () => {
    if (!entry) return;
    const { jsPDF } = await import('jspdf');
    const doc = new jsPDF();
    doc.setFontSize(18);
    doc.text(entry.title || 'Untitled', 20, 20);
    doc.setFontSize(11);
    const plain = entry.content
      .replace(/<br\s*\/?>/gi, '\n')
      .replace(/<\/(p|h1|h2|h3|li|blockquote)>/gi, '\n')
      .replace(/<[^>]+>/g, '')
      .replace(/&nbsp;/g, ' ')
      .replace(/&amp;/g, '&')
      .replace(/&lt;/g, '<')
      .replace(/&gt;/g, '>');
    const lines = doc.splitTextToSize(plain, 170);
    doc.text(lines, 20, 32);
    doc.save(`${(entry.title || 'entry').slice(0, 40)}.pdf`);
  };

  const toggleTag = async (tagId: string) => {
    if (!entry) return;
    const next = entryTagIds.includes(tagId)
      ? entryTagIds.filter((x) => x !== tagId)
      : [...entryTagIds, tagId];
    setEntryTagIds(next);
    await dataApi.setEntryTags(entry.id, next);
  };

  const toggleFolder = async (folderId: string) => {
    if (!entry) return;
    const next = entryFolderIds.includes(folderId)
      ? entryFolderIds.filter((x) => x !== folderId)
      : [...entryFolderIds, folderId];
    setEntryFolderIds(next);
    await dataApi.setEntryFolders(entry.id, next);
  };

  const createTagInline = async () => {
    const name = prompt('New tag name');
    if (!name?.trim()) return;
    const tg = await dataApi.createTag(name.trim());
    setAllTags((prev) => [...prev, tg]);
    if (entry) {
      await dataApi.setEntryTags(entry.id, [...entryTagIds, tg.id]);
      setEntryTagIds((prev) => [...prev, tg.id]);
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center py-20">
        <Loader2 className="w-8 h-8 animate-spin" style={{ color: 'var(--accent)' }} />
      </div>
    );
  }

  if (error || !entry) {
    return (
      <div className="hd-card p-8 text-center">
        <AlertCircle className="w-8 h-8 mx-auto mb-2" style={{ color: 'var(--error)' }} />
        <p style={{ color: 'var(--error)' }}>{error ?? 'Entry not found'}</p>
        <button className="hd-btn mt-3" onClick={() => nav('/library')}>Back to Library</button>
      </div>
    );
  }

  const layout = theme.layout;
  const bookLayout = layout === 'book';

  return (
    <div className="fade-up pb-28">
      {/* header */}
      <div className="flex items-center justify-between gap-2 mb-4 flex-wrap">
        <div className="flex items-center gap-2">
          <button className="hd-btn !p-2" onClick={() => nav('/library')} aria-label="Back">
            <ArrowLeft className="w-5 h-5" />
          </button>
          <span
            className="text-sm px-2 hd-border rounded-lg py-1.5 inline-flex items-center gap-1.5"
            style={{ color: 'var(--text-2)', background: 'var(--surface)' }}
          >
            <CalendarDays className="w-4 h-4" />
            {formatDateLabel(entry.date)}
          </span>
        </div>
        <div className="flex items-center gap-2 flex-wrap">
          <SaveBadge state={saveState} errorDetail={lastError} />
          <button className="hd-btn !p-2" title={reviewMode ? 'Edit' : 'Review mode'} onClick={() => setReviewMode(!reviewMode)}>
            {reviewMode ? <Pencil className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
          </button>
          <button className="hd-btn !p-2" title="Share" onClick={share}>
            <Share2 className="w-5 h-5" />
          </button>
          <button className="hd-btn !p-2" title="Export PDF" onClick={exportPdf}>
            <FileDown className="w-5 h-5" />
          </button>
          <button
            className="hd-btn !p-2"
            title="Pin to Home"
            style={entry.pinned_home ? { background: 'var(--surface-2)' } : {}}
            onClick={() => {
              const next = !entry.pinned_home;
              patchEntry({ pinned_home: next });
              patchBlocks({ pinnedHome: next });
            }}
          >
            <Star className="w-5 h-5" fill={entry.pinned_home ? 'var(--accent)' : 'none'} />
          </button>
          <button
            className="hd-btn hd-btn-primary"
            onClick={async () => {
              if (entry.type === 'book') {
                const b = entry.blocks.book ?? {};
                const valid = Boolean(
                  entry.title.trim() && b.coverUrl && (b.rating ?? 0) > 0 && b.recommended !== undefined && b.recommended !== null
                );
                if (!valid) {
                  setTriedSubmit(true);
                  return;
                }
              }
              await flushNow();
              nav('/library');
            }}
          >
            {t('done')}
          </button>
        </div>
      </div>

      {/* entry paper */}
      <div
        id="entry-paper"
        className="hd-card relative mx-auto"
        style={{
          background: theme.bgColor,
          borderColor: theme.outlineColor,
          maxWidth: bookLayout ? 900 : 760,
          borderStyle: theme.outlineStyle === 'dashed' ? 'dashed' : 'solid',
        }}
      >
        {theme.pattern !== 'none' && (
          <div
            className={`pattern-${theme.pattern} absolute inset-0 rounded-[inherit] pointer-events-none`}
            style={{ ['--pat-color' as string]: theme.patternColor, opacity: 0.35 }}
          />
        )}
        <DrawingCanvas
          layers={entry.blocks.drawing ?? []}
          onChange={setLayers}
          active={drawMode && !reviewMode}
          color={drawColor}
          width={drawWidth}
          opacity={drawOpacity}
          tool={drawTool}
        />

        <div
          className="relative p-5 sm:p-8"
          style={{ color: theme.textColor, fontFamily: theme.fontFamily, fontSize: theme.fontSize }}
        >
          {entry.type === 'book' ? (
            <BookFields
              entry={entry}
              onBlocks={onBlocksField}
              onUploadImage={onUploadImage}
              patchEntry={patchEntry}
              accent={theme.accentColor}
              triedSubmit={triedSubmit}
            />
          ) : entry.type === 'diary' ? (
            <>
              {/* title — not autofocused (keyboard opens only on deliberate tap) */}
              {!reviewMode ? (
                <input
                  className="w-full bg-transparent border-none outline-none text-2xl font-bold mb-3"
                  style={{ color: theme.textColor }}
                  placeholder="Title…"
                  value={entry.title}
                  onChange={(e) => patchEntry({ title: e.target.value })}
                />
              ) : (
                <h1 className="text-2xl font-bold mb-3" style={{ color: theme.textColor }}>
                  {entry.title || 'Untitled'}
                </h1>
              )}
            </>
          ) : (
            <>
              {/* title — not autofocused (keyboard opens only on deliberate tap) */}
              {!reviewMode ? (
                <input
                  className="w-full bg-transparent border-none outline-none text-2xl font-bold mb-3"
                  style={{ color: theme.textColor }}
                  placeholder="Title…"
                  value={entry.title}
                  onChange={(e) => patchEntry({ title: e.target.value })}
                />
              ) : (
                <h1 className="text-2xl font-bold mb-3" style={{ color: theme.textColor }}>
                  {entry.title || 'Untitled'}
                </h1>
              )}

              {/* rating */}
              <RatingControl
                config={entry.blocks.rating ?? { value: 0, max: 5, icon: 'star', color: theme.accentColor, size: 22 }}
                onChange={(rating) => patchBlocks({ rating })}
              />
            </>
          )}

          {/* rich text */}
          {reviewMode ? (
            <div
              className="entry-content"
              dangerouslySetInnerHTML={{ __html: entry.content }}
              style={{ color: theme.textColor }}
            />
          ) : (
            <div
              ref={richRef}
              id="entry-rich-text"
              className="entry-content outline-none min-h-[200px]"
              contentEditable
              suppressContentEditableWarning
              onInput={(e) => {
                const html = (e.target as HTMLDivElement).innerHTML;
                setEntry((prev) => (prev ? { ...prev, content: html } : prev));
                if (!isNew) queue({ content: html });
              }}
              onBlur={(e) => {
                const html = (e.target as HTMLDivElement).innerHTML;
                if (!isNew) queue({ content: html });
              }}
            />
          )}

          {/* gallery media */}
          {(entry.blocks.media?.length ?? 0) > 0 && (
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 mt-4">
              {(entry.blocks.media ?? []).filter((m) => m.kind === 'image').map((m) => (
                <div key={m.id} className="relative group">
                  <img
                    src={m.external ? m.url : mediaUrls[m.url] ?? ''}
                    alt={m.caption ?? ''}
                    className="w-full rounded-lg hd-border object-cover"
                    style={{
                      opacity: m.transform?.opacity ?? 1,
                      transform: `rotate(${m.transform?.rotation ?? 0}deg) scale(${m.transform?.scale ?? 1})`,
                      aspectRatio: m.transform?.crop?.ratio === '1:1' ? '1/1' : m.transform?.crop?.ratio === '3:4' ? '3/4' : m.transform?.crop?.ratio === '4:3' ? '4/3' : undefined,
                    }}
                  />
                  <button
                    className="absolute top-1 right-1 w-7 h-7 rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"
                    style={{ background: 'rgba(0,0,0,0.55)', color: '#fff' }}
                    onClick={() => patchBlocks({ media: (entry.blocks.media ?? []).filter((x) => x.id !== m.id) })}
                    aria-label="Remove image"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                  <button
                    className="absolute top-1 left-1 w-7 h-7 rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"
                    style={{ background: 'rgba(0,0,0,0.55)', color: '#fff' }}
                    title={m.transform?.locked ? 'Unlock position' : 'Lock position'}
                    onClick={() => {
                      const media = (entry.blocks.media ?? []).map((x) =>
                        x.id === m.id ? { ...x, transform: { ...x.transform, locked: !x.transform?.locked } } : x
                      );
                      patchBlocks({ media });
                    }}
                  >
                    {m.transform?.locked ? <Lock className="w-3.5 h-3.5" /> : <Unlock className="w-3.5 h-3.5" />}
                  </button>
                </div>
              ))}
            </div>
          )}

          {/* audio attachments */}
          {(entry.blocks.media ?? []).filter((m) => m.kind === 'audio').length > 0 && (
            <div className="mt-4 space-y-2">
              {(entry.blocks.media ?? []).filter((m) => m.kind === 'audio').map((m) => (
                <div key={m.id} className="flex items-center gap-2 hd-card !rounded-lg p-2">
                  <Music className="w-4 h-4" style={{ color: 'var(--accent)' }} />
                  {m.external ? (
                    <a href={m.url} target="_blank" rel="noreferrer" className="text-sm underline" style={{ color: 'var(--accent)' }}>
                      External audio
                    </a>
                  ) : (
                    <audio controls src={mediaUrls[m.url] ?? ''} className="flex-1 h-8" />
                  )}
                  <button
                    className="hd-btn !p-1.5"
                    onClick={async () => {
                      if (!m.external) await dataApi.deleteMedia(m.url).catch(() => {});
                      patchBlocks({ media: (entry.blocks.media ?? []).filter((x) => x.id !== m.id) });
                    }}
                    aria-label="Remove audio"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* tags + folders row */}
      <div className="flex flex-wrap gap-2 mt-4 items-center">
        <button className="hd-btn text-sm" onClick={() => setShowTagsPanel(!showTagsPanel)}>
          <TagIcon className="w-4 h-4" /> Tags ({entryTagIds.length})
        </button>
        {folders.length > 0 && (
          <select
            className="hd-input !w-auto text-sm"
            value=""
            onChange={(e) => e.target.value && toggleFolder(e.target.value)}
            aria-label="Add to folder"
          >
            <option value="">Add to folder…</option>
            {folders.map((f) => (
              <option key={f.id} value={f.id}>
                {entryFolderIds.includes(f.id) ? '✓ ' : ''}{f.name}
              </option>
            ))}
          </select>
        )}
      </div>

      {showTagsPanel && (
        <div className="hd-card p-3 mt-2 flex flex-wrap gap-2">
          {allTags.map((tg) => (
            <button
              key={tg.id}
              onClick={() => toggleTag(tg.id)}
              className="text-xs px-2.5 py-1 rounded-full border"
              style={{
                background: tg.chip_bg,
                color: tg.chip_text,
                borderColor: entryTagIds.includes(tg.id) ? tg.chip_text : 'var(--border)',
                borderWidth: entryTagIds.includes(tg.id) ? 2 : 1,
              }}
            >
              {entryTagIds.includes(tg.id) ? '✓ ' : ''}{tg.name}
            </button>
          ))}
          <button className="hd-btn text-xs" onClick={createTagInline}>+ New tag</button>
        </div>
      )}

      {mediaError && (
        <p className="text-sm mt-2 px-3 py-2 rounded-lg" style={{ background: 'color-mix(in srgb, var(--error) 12%, transparent)', color: 'var(--error)' }}>
          {mediaError}
        </p>
      )}

      {/* bottom toolbars */}
      {!reviewMode && (
        <>
          {drawMode ? (
            <div className="fixed bottom-0 left-0 right-0 z-30 p-2" style={{ background: 'color-mix(in srgb, var(--bg) 88%, transparent)', backdropFilter: 'blur(8px)' }}>
              <div className="max-w-3xl mx-auto space-y-2">
                <DrawingControls
                  tool={drawTool}
                  setTool={setDrawTool}
                  color={drawColor}
                  setColor={setDrawColor}
                  width={drawWidth}
                  setWidth={setDrawWidth}
                  opacity={drawOpacity}
                  setOpacity={setDrawOpacity}
                  onUndo={undoDraw}
                  onRedo={redoDraw}
                  canUndo={drawingHistory.current.length > 0}
                  canRedo={drawingFuture.current.length > 0}
                  zoom={1}
                  setZoom={() => {}}
                />
                <button className="hd-btn hd-btn-primary text-sm w-full justify-center" onClick={() => setDrawMode(false)}>
                  {t('done')} drawing
                </button>
              </div>
            </div>
          ) : (
            <div className="fixed bottom-0 left-0 right-0 z-30 p-2" style={{ background: 'color-mix(in srgb, var(--bg) 88%, transparent)', backdropFilter: 'blur(8px)' }}>
              <div className="max-w-3xl mx-auto flex flex-col gap-2">
                <FormatToolbar
                  onFormat={(cmd, val) => execFormat(cmd, val)}
                  onFontSize={(size) => execFormat('fontSize', size)}
                  onColor={(c) => execFormat('foreColor', c)}
                  onHighlight={(c) => execFormat('hiliteColor', c)}
                  onInsertDivider={insertDivider}
                  onLink={insertLink}
                  fontSize="3"
                  color="#49382E"
                  highlight="#FFF3B0"
                />
                <div className="flex gap-2 overflow-x-auto pb-1">
                  <label className="hd-btn text-sm cursor-pointer whitespace-nowrap">
                    <ImageIcon className="w-4 h-4" /> Photo
                    <input
                      type="file"
                      accept="image/*"
                      className="hidden"
                      onChange={async (e) => {
                        const f = e.target.files?.[0];
                        if (f) await onUploadImage(f, entry.type === 'hangout' ? 'gallery' : 'media');
                      }}
                    />
                  </label>
                  <label className="hd-btn text-sm cursor-pointer whitespace-nowrap">
                    <Music className="w-4 h-4" /> Audio
                    <input
                      type="file"
                      accept="audio/*"
                      className="hidden"
                      onChange={async (e) => {
                        const f = e.target.files?.[0];
                        if (f) await addAudio(f);
                      }}
                    />
                  </label>
                  <button className="hd-btn text-sm whitespace-nowrap" onClick={() => setDrawMode(true)}>
                    <Pencil className="w-4 h-4" /> Draw
                  </button>
                  <button className="hd-btn text-sm whitespace-nowrap" onClick={() => { setShowRatingPanel(!showRatingPanel); setShowEmojiPanel(false); }}>
                    <Star className="w-4 h-4" /> Add Rating
                  </button>
                  <button className="hd-btn text-sm whitespace-nowrap" onClick={() => { setShowEmojiPanel(!showEmojiPanel); setShowRatingPanel(false); }}>
                    <Smile className="w-4 h-4" /> Add Emotion
                  </button>
                  <button className="hd-btn text-sm whitespace-nowrap" onClick={() => setShowTheme(!showTheme)}>
                    <Palette className="w-4 h-4" /> Theme
                  </button>
                  <select
                    className="hd-input !w-auto text-sm"
                    value={theme.layout}
                    onChange={(e) => patchBlocks({ theme: { ...theme, layout: e.target.value as EntryTheme['layout'] } })}
                    aria-label="Layout"
                  >
                    <option value="full">Full page</option>
                    <option value="book">Book</option>
                    <option value="postcard">Postcard</option>
                    <option value="sketchbook">Sketchbook</option>
                  </select>
                </div>
                {showTheme && (
                  <div className="hd-card p-3 space-y-2">
                    <div className="flex flex-wrap gap-2 items-center">
                      <ColorRow label="Paper" value={theme.bgColor} onChange={(c) => patchBlocks({ theme: { ...theme, bgColor: c } })} />
                      <ColorRow label="Text" value={theme.textColor} onChange={(c) => patchBlocks({ theme: { ...theme, textColor: c } })} />
                      <ColorRow label="Outline" value={theme.outlineColor} onChange={(c) => patchBlocks({ theme: { ...theme, outlineColor: c } })} />
                      <ColorRow label="Accent" value={theme.accentColor} onChange={(c) => patchBlocks({ theme: { ...theme, accentColor: c } })} />
                      <ColorRow label="Pattern" value={theme.patternColor} onChange={(c) => patchBlocks({ theme: { ...theme, patternColor: c } })} />
                    </div>
                    <div className="flex flex-wrap gap-2 items-center">
                      <select
                        className="hd-input !w-auto text-sm"
                        value={theme.pattern}
                        onChange={(e) => patchBlocks({ theme: { ...theme, pattern: e.target.value as EntryTheme['pattern'] } })}
                        aria-label="Paper pattern"
                      >
                        <option value="none">No pattern</option>
                        <option value="dots">Dots</option>
                        <option value="grid">Grid</option>
                        <option value="lined">Lined</option>
                        <option value="graph">Graph</option>
                      </select>
                      <select
                        className="hd-input !w-auto text-sm"
                        value={theme.fontFamily}
                        onChange={(e) => patchBlocks({ theme: { ...theme, fontFamily: e.target.value } })}
                        aria-label="Entry font"
                      >
                        {ENTRY_FONTS.map((f) => (
                          <option key={f.id} value={f.stack}>{f.name}</option>
                        ))}
                      </select>
                      <input
                        type="number"
                        min={12}
                        max={28}
                        className="hd-input !w-20 text-sm"
                        value={theme.fontSize}
                        onChange={(e) => patchBlocks({ theme: { ...theme, fontSize: Number(e.target.value) } })}
                        aria-label="Font size"
                      />
                    </div>
                  </div>
                )}
                {showRatingPanel && (
                  <div className="hd-card p-3 space-y-2">
                    <p className="text-xs font-semibold" style={{ color: 'var(--text-2)' }}>Tap a rating to place it on the page</p>
                    <div className="flex flex-wrap gap-2">
                      {[1, 2, 3, 4, 5].map((n) => (
                        <button
                          key={n}
                          type="button"
                          className="flex items-center gap-0.5 px-3 py-1.5 rounded-full border-2 transition-colors"
                          style={{ background: 'var(--surface)', borderColor: 'var(--border)' }}
                          onClick={() => {
                            patchBlocks({ rating: { value: n, max: 5, icon: 'star', color: theme.accentColor, size: 22 } });
                            setShowRatingPanel(false);
                          }}
                          aria-label={`Set rating to ${n}`}
                        >
                          {Array.from({ length: n }).map((_, i) => (
                            <Star key={i} className="w-4 h-4" style={{ color: theme.accentColor, fill: theme.accentColor }} />
                          ))}
                        </button>
                      ))}
                    </div>
                  </div>
                )}
                {showEmojiPanel && (
                  <div className="hd-card p-3 space-y-2">
                    <p className="text-xs font-semibold" style={{ color: 'var(--text-2)' }}>Tap an emotion to record how you felt</p>
                    <div className="flex flex-wrap gap-2">
                      {Object.keys(MOOD_COLORS).map((label) => (
                        <button
                          key={label}
                          type="button"
                          className="px-3 py-1.5 rounded-full border-2 text-sm font-semibold transition-colors"
                          style={{ background: MOOD_COLORS[label], borderColor: MOOD_COLORS[label], color: '#fff' }}
                          onClick={() => {
                            const mood = { moodId: label.toLowerCase(), label, color: MOOD_COLORS[label], intensity: 5 };
                            const existing = entry?.blocks.mood ?? [];
                            patchBlocks({ mood: existing.some((m) => m.label === label) ? existing.filter((m) => m.label !== label) : [...existing, mood] });
                            setShowEmojiPanel(false);
                          }}
                          aria-label={`Add emotion ${label}`}
                        >
                          {label}
                        </button>
                      ))}
                    </div>
                  </div>
                )}
                {uploadingMedia && (
                  <p className="text-sm text-center" style={{ color: 'var(--text-2)' }}>Uploading…</p>
                )}
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
}

function SaveBadge({ state, errorDetail }: { state: 'idle' | 'saving' | 'saved' | 'error'; errorDetail?: string | null }) {
  if (state === 'idle') return null;
  if (state === 'error') {
    return (
      <span
        className="inline-flex items-center gap-1 text-xs font-semibold px-2 py-1 rounded-lg"
        style={{ color: 'var(--error)', background: 'color-mix(in srgb, var(--error) 10%, transparent)' }}
        title={errorDetail ?? 'Check your connection and try again'}
      >
        <AlertCircle className="w-3.5 h-3.5" /> Save failed — check connection
      </span>
    );
  }
  const map = {
    saving: { icon: <Loader2 className="w-3.5 h-3.5 animate-spin" />, text: 'Saving…', color: 'var(--text-2)' },
    saved: { icon: <Check className="w-3.5 h-3.5" />, text: 'Saved', color: 'var(--success)' },
  } as const;
  const m = map[state];
  return (
    <span className="inline-flex items-center gap-1 text-xs font-semibold" style={{ color: m.color }}>
      {m.icon} {m.text}
    </span>
  );
}

function RatingControl({ config, onChange }: { config: RatingConfig; onChange: (c: RatingConfig) => void }) {
  return (
    <div className="flex items-center gap-1 mb-3">
      {Array.from({ length: config.max }).map((_, i) => (
        <button
          key={i}
          onClick={() => onChange({ ...config, value: i + 1 === config.value ? 0 : i + 1 })}
          aria-label={`Rate ${i + 1}`}
          className="transition-transform hover:scale-110"
        >
          <Star
            style={{
              width: config.size,
              height: config.size,
              color: i < config.value ? config.color : 'var(--border)',
              fill: i < config.value ? config.color : 'none',
            }}
          />
        </button>
      ))}
    </div>
  );
}

function ColorRow({ label, value, onChange }: { label: string; value: string; onChange: (c: string) => void }) {
  return (
    <label className="flex items-center gap-1.5 text-xs" style={{ color: 'var(--text-2)' }}>
      {label}
      <input type="color" value={value} onChange={(e) => onChange(e.target.value)} className="w-7 h-7 rounded cursor-pointer border-0 bg-transparent p-0" />
    </label>
  );
}
