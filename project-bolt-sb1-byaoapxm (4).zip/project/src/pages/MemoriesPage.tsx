import { useEffect, useMemo, useState } from 'react';
import { ArrowLeft, Loader2, MapPin, Search } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { dataApi } from '@/lib/data';
import type { Entry } from '@/lib/types';
import { MOOD_ICONS } from '@/lib/types';
import { MoodIcon } from '@/pages/HomePage';

export default function MemoriesPage() {
  const nav = useNavigate();
  const [entries, setEntries] = useState<Entry[]>([]);
  const [urls, setUrls] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [sort, setSort] = useState<'date' | 'rating'>('date');

  useEffect(() => {
    let alive = true;
    (async () => {
      try {
        const es = await dataApi.listEntries({ types: ['hangout'] });
        if (!alive) return;
        setEntries(es);
        const next: Record<string, string> = {};
        const paths = new Set<string>();
        for (const e of es) {
          for (const p of e.blocks.hangout?.photos ?? []) {
            if (!p.external) paths.add(p.url);
          }
        }
        const arr = [...paths];
        for (let i = 0; i < arr.length; i += 20) {
          const batch = arr.slice(i, i + 20);
          const results = await Promise.all(
            batch.map(async (p) => {
              try {
                return [p, await dataApi.createSignedUrl(p)] as const;
              } catch {
                return null;
              }
            })
          );
          for (const r of results) if (r) next[r[0]] = r[1];
        }
        if (alive) setUrls(next);
      } finally {
        if (alive) setLoading(false);
      }
    })();
    return () => {
      alive = false;
    };
  }, []);

  const filtered = useMemo(() => {
    const s = search.trim().toLowerCase();
    const out = entries.filter((e) => {
      if (!s) return true;
      const hay = [e.title, e.blocks.hangout?.placeName, e.blocks.hangout?.description, e.blocks.hangout?.location]
        .filter(Boolean)
        .join(' ')
        .toLowerCase();
      return hay.includes(s);
    });
    return out.sort((a, b) => {
      if (sort === 'rating') {
        return (b.blocks.hangout?.placeRating ?? 0) - (a.blocks.hangout?.placeRating ?? 0);
      }
      return (b.blocks.hangout?.visitDate ?? b.date).localeCompare(a.blocks.hangout?.visitDate ?? a.date);
    });
  }, [entries, search, sort]);

  if (loading) {
    return (
      <div className="flex justify-center py-20">
        <Loader2 className="w-8 h-8 animate-spin" style={{ color: 'var(--accent)' }} />
      </div>
    );
  }

  return (
    <div className="space-y-5 fade-up">
      <div className="flex items-center justify-between">
        <button className="hd-btn !p-2" onClick={() => nav('/')} aria-label="Back">
          <ArrowLeft className="w-5 h-5" />
        </button>
        <h1 className="text-2xl font-bold flex items-center gap-2" style={{ color: 'var(--text)' }}>
          <MapPin className="w-6 h-6" style={{ color: 'var(--accent)' }} /> Memories
        </h1>
        <span className="w-10" />
      </div>

      <div className="flex gap-2 items-center flex-wrap">
        <div className="relative flex-1 min-w-48">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4" style={{ color: 'var(--text-2)' }} />
          <input className="hd-input !pl-9" placeholder="Search places…" value={search} onChange={(e) => setSearch(e.target.value)} />
        </div>
        <select className="hd-input !w-auto text-sm" value={sort} onChange={(e) => setSort(e.target.value as 'date' | 'rating')}>
          <option value="date">By date</option>
          <option value="rating">By rating</option>
        </select>
      </div>

      {filtered.length === 0 ? (
        <div className="hd-card p-10 text-center">
          <MapPin className="w-10 h-10 mx-auto mb-3" style={{ color: 'var(--outline)' }} />
          <p style={{ color: 'var(--text-2)' }}>
            No hangout memories yet. Create a Hangout entry to capture a place you visited.
          </p>
          <button className="hd-btn hd-btn-primary mt-3" onClick={() => nav('/editor/new?type=hangout')}>
            + New Hangout
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {filtered.map((e) => {
            const h = e.blocks.hangout ?? {};
            const photos = h.photos ?? [];
            return (
              <button key={e.id} className="hd-card hd-card-hover overflow-hidden text-left" onClick={() => nav(`/entry/${e.id}`)}>
                {photos.length > 0 ? (
                  <div className="grid grid-cols-2">
                    {photos.slice(0, 4).map((p, i) => (
                      <img
                        key={p.id}
                        src={p.external ? p.url : urls[p.url] ?? ''}
                        alt=""
                        className={`w-full object-cover ${photos.length === 1 ? 'col-span-2 aspect-video' : 'aspect-square'} ${i === 0 && photos.length >= 3 ? 'row-span-2 h-full' : ''}`}
                        loading="lazy"
                        style={{ aspectRatio: '1/1' }}
                      />
                    ))}
                  </div>
                ) : (
                  <div className="h-32 flex items-center justify-center" style={{ background: 'var(--surface-2)' }}>
                    <MapPin className="w-8 h-8" style={{ color: 'var(--outline)' }} />
                  </div>
                )}
                <div className="p-3">
                  <p className="font-bold" style={{ color: 'var(--text)' }}>
                    {h.placeName || e.title || 'Untitled place'}
                  </p>
                  <p className="text-xs" style={{ color: 'var(--text-2)' }}>
                    {h.visitDate ?? e.date}
                    {h.placeRating ? ` · ${'★'.repeat(Math.round(h.placeRating))}` : ''}
                  </p>
                  {h.description && (
                    <p className="text-sm mt-1 line-clamp-2" style={{ color: 'var(--text-2)' }}>
                      {h.description}
                    </p>
                  )}
                </div>
              </button>
            );
          })}
        </div>
      )}
    </div>
  );
}
