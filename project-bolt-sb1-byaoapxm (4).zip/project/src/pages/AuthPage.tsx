import { useState } from 'react';
import { supabase } from '@/lib/supabase';
import { useI18n } from '@/lib/i18n';
import { BookOpen, Loader2, Mail, User, KeyRound } from 'lucide-react';

type Mode = 'signin' | 'signup' | 'recover';

export default function AuthPage({ onBack }: { onBack?: () => void }) {
  const { t } = useI18n();
  const [mode, setMode] = useState<Mode>('signin');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [displayName, setDisplayName] = useState('');
  const [username, setUsername] = useState('');
  const [loginIdentifier, setLoginIdentifier] = useState('');
  const [loginByUsername, setLoginByUsername] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [info, setInfo] = useState<string | null>(null);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setError(null);
    setInfo(null);
    try {
      if (mode === 'signin') {
        let addr = email.trim();
        if (loginByUsername) {
          // Username sign-in resolves through a server-side function; the email
          // is never exposed to the browser.
          const res = await fetch(
            `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/username-login`,
            {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json',
                Authorization: `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
              },
              body: JSON.stringify({ username: loginIdentifier, password }),
            }
          );
          const body = await res.json();
          if (!res.ok || !body.access_token) {
            throw new Error(body.error ?? 'Sign-in failed');
          }
          const { error: sErr } = await supabase.auth.setSession({
            access_token: body.access_token,
            refresh_token: body.refresh_token,
          });
          if (sErr) throw sErr;
          setBusy(false);
          return;
        }
        const { error: err } = await supabase.auth.signInWithPassword({
          email: addr,
          password,
        });
        if (err) throw err;
      } else if (mode === 'signup') {
        const uname = username.trim().toLowerCase().replace(/^@/, '');
        if (!/^[a-z0-9_]{3,20}$/.test(uname)) {
          throw new Error('Username must be 3-20 characters: letters, numbers, underscores.');
        }
        const { error: err } = await supabase.auth.signUp({
          email: email.trim(),
          password,
          options: { data: { display_name: displayName.trim() || uname } },
        });
        if (err) throw err;
        setInfo('Check your email to confirm your account, then sign in.');
        setMode('signin');
      } else {
        const { error: err } = await supabase.auth.resetPasswordForEmail(email.trim());
        if (err) throw err;
        setInfo('Password reset email sent. Check your inbox.');
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Something went wrong');
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4" style={{ background: 'var(--bg)' }}>
      <div className="w-full max-w-sm">
        <div className="text-center mb-6 fade-up">
          <div
            className="inline-flex items-center justify-center w-16 h-16 hd-border mb-3"
            style={{ background: 'var(--surface-2)' }}
          >
            <BookOpen className="w-8 h-8" style={{ color: 'var(--accent)' }} />
          </div>
          <h1 className="text-3xl font-bold" style={{ color: 'var(--text)' }}>
            Diary Bebek
          </h1>
          <p style={{ color: 'var(--text-2)' }}>your little corner of memories</p>
        </div>

        <div className="hd-card p-6 fade-up">
          {mode === 'signin' && (
            <h2 className="text-xl font-bold mb-4" style={{ color: 'var(--text)' }}>
              {t('welcomeBack')}
            </h2>
          )}
          {mode === 'signup' && (
            <h2 className="text-xl font-bold mb-4" style={{ color: 'var(--text)' }}>
              {t('createAccount')}
            </h2>
          )}
          {mode === 'recover' && (
            <h2 className="text-xl font-bold mb-4" style={{ color: 'var(--text)' }}>
              {t('resetPassword')}
            </h2>
          )}

          <form onSubmit={submit} className="space-y-3">
            {mode === 'signin' && (
              <>
                <div className="flex gap-2 mb-2">
                  <button
                    type="button"
                    onClick={() => setLoginByUsername(false)}
                    className="hd-btn flex-1 justify-center"
                    style={loginByUsername ? {} : { background: 'var(--surface-2)' }}
                  >
                    <Mail className="w-4 h-4" /> {t('email')}
                  </button>
                  <button
                    type="button"
                    onClick={() => setLoginByUsername(true)}
                    className="hd-btn flex-1 justify-center"
                    style={loginByUsername ? { background: 'var(--surface-2)' } : {}}
                  >
                    <User className="w-4 h-4" /> {t('username')}
                  </button>
                </div>
                {loginByUsername ? (
                  <input
                    className="hd-input"
                    placeholder="@username"
                    value={loginIdentifier}
                    onChange={(e) => setLoginIdentifier(e.target.value)}
                    autoComplete="username"
                  />
                ) : (
                  <input
                    className="hd-input"
                    type="email"
                    placeholder={t('email')}
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    autoComplete="email"
                  />
                )}
                <input
                  className="hd-input"
                  type="password"
                  placeholder={t('password')}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  autoComplete="current-password"
                />
                <button
                  type="button"
                  className="text-sm underline"
                  style={{ color: 'var(--text-2)' }}
                  onClick={() => setMode('recover')}
                >
                  {t('forgotPassword')}
                </button>
              </>
            )}

            {mode === 'signup' && (
              <>
                <input
                  className="hd-input"
                  placeholder={t('displayName')}
                  value={displayName}
                  onChange={(e) => setDisplayName(e.target.value)}
                />
                <input
                  className="hd-input"
                  placeholder="@username (3-20 chars)"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  autoComplete="username"
                />
                <input
                  className="hd-input"
                  type="email"
                  required
                  placeholder={t('email')}
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  autoComplete="email"
                />
                <input
                  className="hd-input"
                  type="password"
                  required
                  minLength={6}
                  placeholder={t('password')}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  autoComplete="new-password"
                />
              </>
            )}

            {mode === 'recover' && (
              <input
                className="hd-input"
                type="email"
                required
                placeholder={t('email')}
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                autoComplete="email"
              />
            )}

            {error && (
              <p className="text-sm px-3 py-2 rounded-lg" style={{ background: 'color-mix(in srgb, var(--error) 12%, transparent)', color: 'var(--error)' }}>
                {error}
              </p>
            )}
            {info && (
              <p className="text-sm px-3 py-2 rounded-lg" style={{ background: 'color-mix(in srgb, var(--success) 12%, transparent)', color: 'var(--success)' }}>
                {info}
              </p>
            )}

            <button type="submit" disabled={busy} className="hd-btn hd-btn-primary w-full justify-center">
              {busy ? <Loader2 className="w-4 h-4 animate-spin" /> : <KeyRound className="w-4 h-4" />}
              {mode === 'signin' ? t('signIn') : mode === 'signup' ? t('createAccount') : t('resetPassword')}
            </button>
          </form>

          <div className="mt-4 text-center text-sm" style={{ color: 'var(--text-2)' }}>
            {mode === 'signin' ? (
              <button className="underline" onClick={() => setMode('signup')}>
                New here? {t('createAccount')}
              </button>
            ) : (
              <button className="underline" onClick={() => setMode('signin')}>
                Already have an account? {t('signIn')}
              </button>
            )}
          </div>

          {onBack && (
            <div className="mt-3 text-center">
              <button className="text-sm underline" style={{ color: 'var(--text-2)' }} onClick={onBack}>
                Back
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
