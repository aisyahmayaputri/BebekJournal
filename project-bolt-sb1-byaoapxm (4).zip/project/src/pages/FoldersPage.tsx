import { useEffect, useState } from 'react';
import { ArrowLeft, Loader2, Folder as FolderIcon, Plus, Trash2, Pencil } from 'lucide-react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { dataApi } from '@/lib/data';
import { useI18n } from '@/lib/i18n';
import type { Folder } from '@/lib/types';

const FOLDER_COLORS = ['#B99A79', '#C05B4D', '#E8B94A', '#6B9A6E', '#6FA6C9', '#A98BC0'];
const FOLDER_ICONS = ['folder', 'heart', 'star', 'book', 'map-pin', 'music'];

export default function FoldersPage() {
  const nav = useNavigate();
  const [params] = useSearchParams();
  const { t } = useI18n();
  const [folders, setFolders] = useState<Folder[]>([]);
  const [loading, setLoading] = useState(true);
  const [creating, setCreating] = useState(false);
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [color, setColor] = useState(FOLDER_COLORS[0]);
  const [icon, setIcon] = useState(FOLDER_ICONS[0]);

  const load = async () => {
    try {
      setFolders(await dataApi.listFolders());
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
    if (params.get('new') === '1') setCreating(true);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const create = async () => {
    if (!name.trim()) return;
    await dataApi.createFolder({ name: name.trim(), description: description.trim(), color, icon });
    setName('');
    setDescription('');
    setCreating(false);
    load();
  };

  const remove = async (id: string) => {
    if (!confirm('Delete this folder? Entries inside are kept, only the folder is removed.')) return;
    await dataApi.deleteFolder(id);
    load();
  };

  const rename = async (f: Folder) => {
    const name2 = prompt('Folder name', f.name);
    if (!name2?.trim()) return;
    await dataApi.updateFolder(f.id, { name: name2.trim() });
    load();
  };

  if (loading) {
    return (
      <div className="flex justify-center py-20">
        <Loader2 className="w-8 h-8 animate-spin" style={{ color: 'var(--accent)' }} />
      </div>
    );
  }

  return (
    <div className="space-y-5 fade-up">
      <div className="flex items-center justify-between">
        <button className="hd-btn !p-2" onClick={() => nav('/')} aria-label="Back">
          <ArrowLeft className="w-5 h-5" />
        </button>
        <h1 className="text-2xl font-bold flex items-center gap-2" style={{ color: 'var(--text)' }}>
          <FolderIcon className="w-6 h-6" style={{ color: 'var(--accent)' }} /> Folders
        </h1>
        <button className="hd-btn !p-2" onClick={() => setCreating(!creating)} aria-label="New folder">
          <Plus className="w-5 h-5" />
        </button>
      </div>

      {creating && (
        <div className="hd-card p-4 space-y-3">
          <input className="hd-input" placeholder="Folder name" value={name} onChange={(e) => setName(e.target.value)} />
          <input className="hd-input" placeholder="Description (optional)" value={description} onChange={(e) => setDescription(e.target.value)} />
          <div className="flex gap-1">
            {FOLDER_COLORS.map((c) => (
              <button key={c} className="w-7 h-7 rounded-full border-2" style={{ background: c, borderColor: color === c ? 'var(--text)' : 'transparent' }} onClick={() => setColor(c)} aria-label={`Color ${c}`} />
            ))}
          </div>
          <div className="flex gap-2 flex-wrap">
            {FOLDER_ICONS.map((ic) => (
              <button key={ic} className="hd-btn text-xs" style={icon === ic ? { background: 'var(--surface-2)' } : {}} onClick={() => setIcon(ic)}>
                {ic}
              </button>
            ))}
          </div>
          <button className="hd-btn hd-btn-primary w-full justify-center" onClick={create}>
            Create folder
          </button>
        </div>
      )}

      {folders.length === 0 ? (
        <div className="hd-card p-10 text-center">
          <FolderIcon className="w-10 h-10 mx-auto mb-3" style={{ color: 'var(--outline)' }} />
          <p style={{ color: 'var(--text-2)' }}>
            No folders yet. Create one to organize entries into collections.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {folders.map((f) => (
            <div key={f.id} className="hd-card p-4" style={{ borderColor: f.color }}>
              <div className="flex items-center justify-between gap-2">
                <button className="text-left flex-1 min-w-0" onClick={() => nav(`/library?folder=${f.id}`)}>
                  <p className="font-bold truncate" style={{ color: f.color }}>
                    {f.name}
                  </p>
                  {f.description && (
                    <p className="text-xs truncate" style={{ color: 'var(--text-2)' }}>{f.description}</p>
                  )}
                </button>
                <button className="hd-btn !p-1.5" onClick={() => rename(f)} aria-label="Rename folder">
                  <Pencil className="w-4 h-4" />
                </button>
                <button className="hd-btn !p-1.5" onClick={() => remove(f.id)} aria-label="Delete folder">
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
      <p className="text-xs text-center" style={{ color: 'var(--text-2)' }}>
        Tip: add entries to folders from inside any entry with the "{t('filterByFolder')}" control in the editor.
      </p>
    </div>
  );
}
