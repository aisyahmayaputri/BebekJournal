import { useEffect, useMemo, useState } from 'react';
import { ArrowLeft, Loader2, BookMarked, Plus, Trash2, Tag as TagIcon } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { dataApi } from '@/lib/data';
import type { Entry, Tag, Folder, Compilation, EntryType } from '@/lib/types';

export default function CompilationsPage() {
  const nav = useNavigate();
  const [compilations, setCompilations] = useState<Compilation[]>([]);
  const [entries, setEntries] = useState<Entry[]>([]);
  const [tags, setTags] = useState<Tag[]>([]);
  const [folders, setFolders] = useState<Folder[]>([]);
  const [loading, setLoading] = useState(true);
  const [creating, setCreating] = useState(false);
  const [busy, setBusy] = useState(false);

  // selection form
  const [title, setTitle] = useState('');
  const [selTypes, setSelTypes] = useState<EntryType[]>([]);
  const [selTags, setSelTags] = useState<string[]>([]);
  const [selFolder, setSelFolder] = useState('');
  const [dateFrom, setDateFrom] = useState('');
  const [dateTo, setDateTo] = useState('');
  const [manualIds, setManualIds] = useState<string[]>([]);

  const load = async () => {
    try {
      const [cs, es, tg, fd] = await Promise.all([
        dataApi.listCompilations(),
        dataApi.listEntries(),
        dataApi.listTags(),
        dataApi.listFolders(),
      ]);
      setCompilations(cs);
      setEntries(es);
      setTags(tg);
      setFolders(fd);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
  }, []);

  const matching = useMemo(() => {
    return entries.filter((e) => {
      if (manualIds.length) return manualIds.includes(e.id);
      if (selTypes.length && !selTypes.includes(e.type)) return false;
      if (selFolder) {
        // folder membership not loaded here; rely on server-side listEntries in real flow
      }
      if (dateFrom && e.date < dateFrom) return false;
      if (dateTo && e.date > dateTo) return false;
      return true;
    });
  }, [entries, selTypes, selFolder, dateFrom, dateTo, manualIds]);

  const create = async () => {
    if (!title.trim() || matching.length === 0) return;
    setBusy(true);
    try {
      const ordered = [...matching].sort((a, b) => a.date.localeCompare(b.date));
      await dataApi.createCompilation({
        title: title.trim(),
        source_ids: ordered.map((e) => e.id),
        snapshot: { entries: ordered },
      });
      setTitle('');
      setCreating(false);
      setManualIds([]);
      setSelTypes([]);
      load();
    } finally {
      setBusy(false);
    }
  };

  const remove = async (id: string) => {
    if (!confirm('Delete this compiled journal? Original entries are not affected.')) return;
    await dataApi.deleteCompilation(id);
    load();
  };

  if (loading) {
    return (
      <div className="flex justify-center py-20">
        <Loader2 className="w-8 h-8 animate-spin" style={{ color: 'var(--accent)' }} />
      </div>
    );
  }

  return (
    <div className="space-y-5 fade-up">
      <div className="flex items-center justify-between">
        <button className="hd-btn !p-2" onClick={() => nav('/')} aria-label="Back">
          <ArrowLeft className="w-5 h-5" />
        </button>
        <h1 className="text-2xl font-bold flex items-center gap-2" style={{ color: 'var(--text)' }}>
          <BookMarked className="w-6 h-6" style={{ color: 'var(--accent)' }} /> Compiled Journals
        </h1>
        <button className="hd-btn !p-2" onClick={() => setCreating(!creating)} aria-label="New compilation">
          <Plus className="w-5 h-5" />
        </button>
      </div>

      {creating && (
        <div className="hd-card p-4 space-y-3">
          <h2 className="font-bold" style={{ color: 'var(--text)' }}>New compilation</h2>
          <input className="hd-input" placeholder="Compilation title (e.g. Summer 2026)" value={title} onChange={(e) => setTitle(e.target.value)} />
          <div className="flex flex-wrap gap-2">
            {(['diary', 'movie', 'book', 'hangout'] as EntryType[]).map((ty) => (
              <button
                key={ty}
                className="hd-btn text-sm capitalize"
                style={selTypes.includes(ty) ? { background: 'var(--surface-2)' } : {}}
                onClick={() => setSelTypes((p) => (p.includes(ty) ? p.filter((x) => x !== ty) : [...p, ty]))}
              >
                {ty}
              </button>
            ))}
          </div>
          {tags.length > 0 && (
            <div className="flex flex-wrap gap-1.5">
              {tags.map((tg) => (
                <button
                  key={tg.id}
                  className="text-xs px-2.5 py-1 rounded-full border"
                  style={{ background: tg.chip_bg, color: tg.chip_text, opacity: selTags.length && !selTags.includes(tg.id) ? 0.4 : 1 }}
                  onClick={() => setSelTags((p) => (p.includes(tg.id) ? p.filter((x) => x !== tg.id) : [...p, tg.id]))}
                >
                  <TagIcon className="inline w-3 h-3 mr-1" />{tg.name}
                </button>
              ))}
            </div>
          )}
          <div className="flex gap-2 flex-wrap items-center">
            <input type="date" className="hd-input !w-auto text-sm" value={dateFrom} onChange={(e) => setDateFrom(e.target.value)} aria-label="From" />
            <span style={{ color: 'var(--text-2)' }}>→</span>
            <input type="date" className="hd-input !w-auto text-sm" value={dateTo} onChange={(e) => setDateTo(e.target.value)} aria-label="To" />
          </div>
          <p className="text-sm" style={{ color: 'var(--text-2)' }}>
            {matching.length} entries will be included, in date order. A snapshot is stored — later edits to the originals won't change this compilation.
          </p>
          <button className="hd-btn hd-btn-primary w-full justify-center" onClick={create} disabled={busy || !title.trim() || matching.length === 0}>
            {busy ? <Loader2 className="w-4 h-4 animate-spin" /> : <Plus className="w-4 h-4" />} Compile
          </button>
        </div>
      )}

      {compilations.length === 0 ? (
        <div className="hd-card p-10 text-center">
          <BookMarked className="w-10 h-10 mx-auto mb-3" style={{ color: 'var(--outline)' }} />
          <p style={{ color: 'var(--text-2)' }}>
            No compiled journals yet. Combine entries by tag, type or date range into a beautiful book.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {compilations.map((c) => (
            <div key={c.id} className="hd-card p-4">
              <div className="flex items-center justify-between gap-2">
                <div className="min-w-0">
                  <p className="font-bold truncate" style={{ color: 'var(--text)' }}>{c.title}</p>
                  <p className="text-xs" style={{ color: 'var(--text-2)' }}>
                    {c.source_ids.length} entries · {new Date(c.created_at).toLocaleDateString()}
                  </p>
                </div>
                <button className="hd-btn !p-1.5" onClick={() => remove(c.id)} aria-label="Delete compilation">
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
