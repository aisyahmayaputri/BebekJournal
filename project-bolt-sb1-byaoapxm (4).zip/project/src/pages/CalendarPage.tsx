import { useEffect, useMemo, useState } from 'react';
import { ArrowLeft, Loader2, Plus, Trash2, CalendarDays, Repeat } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { dataApi } from '@/lib/data';
import { MOOD_COLORS, type CalEvent, type MoodLog } from '@/lib/types';

const EVENT_COLORS = ['#B99A79', '#C05B4D', '#E8B94A', '#6B9A6E', '#6FA6C9', '#A98BC0', '#E58F4A'];

function iso(d: Date) {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

// expand recurring events for a specific month
function eventsOnDate(events: CalEvent[], date: string): CalEvent[] {
  return events.filter((ev) => {
    if (!ev.is_recurring || !ev.recurrence) return ev.date === date;
    const r = ev.recurrence;
    if (ev.date > date) return false;
    if (r.end_date && date > r.end_date) return false;
    const interval = r.interval ?? 1;
    const [ey, em, ed] = ev.date.split('-').map(Number);
    const [yy, mm, dd] = date.split('-').map(Number);
    if (r.frequency === 'weekly') {
      const days = (Date.parse(date) - Date.parse(ev.date)) / 86400000;
      return days >= 0 && days % (7 * interval) === 0;
    }
    if (r.frequency === 'monthly') {
      const months = (yy - ey) * 12 + (mm - em);
      return months >= 0 && months % interval === 0 && dd === ed;
    }
    if (r.frequency === 'yearly') {
      return (yy - ey) % interval === 0 && mm === em && dd === ed;
    }
    return false;
  });
}

export default function CalendarPage() {
  const nav = useNavigate();
  const [cursor, setCursor] = useState(() => iso(new Date()).slice(0, 7));
  const [events, setEvents] = useState<CalEvent[]>([]);
  const [moodLogs, setMoodLogs] = useState<MoodLog[]>([]);
  const [loading, setLoading] = useState(true);
  const [selected, setSelected] = useState<string | null>(null);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({
    name: '',
    date: iso(new Date()),
    description: '',
    color: EVENT_COLORS[0],
    is_recurring: false,
    frequency: 'weekly' as 'weekly' | 'monthly' | 'yearly',
    interval: 1,
    end_date: '',
  });

  const load = async () => {
    try {
      const [ev, ml] = await Promise.all([
        dataApi.listEvents(),
        dataApi.listMoodLogs(`${cursor}-01`, `${cursor}-31`),
      ]);
      setEvents(ev);
      setMoodLogs(ml);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const [y, mo] = cursor.split('-').map(Number);
  const firstDow = (new Date(y, mo - 1, 1).getDay() + 6) % 7;
  const daysInMonth = new Date(y, mo, 0).getDate();

  const cells = useMemo(() => {
    const arr: (string | null)[] = Array(firstDow).fill(null);
    for (let i = 1; i <= daysInMonth; i++) {
      arr.push(`${cursor}-${String(i).padStart(2, '0')}`);
    }
    return arr;
  }, [cursor, firstDow, daysInMonth]);

  const createEvent = async () => {
    if (!form.name.trim()) return;
    await dataApi.createEvent({
      name: form.name.trim(),
      date: form.date,
      description: form.description,
      color: form.color,
      is_recurring: form.is_recurring,
      recurrence: form.is_recurring
        ? { frequency: form.frequency, interval: form.interval, ...(form.end_date ? { end_date: form.end_date } : {}) }
        : null,
    });
    setShowForm(false);
    setForm({ ...form, name: '', description: '' });
    load();
  };

  const deleteEvent = async (id: string) => {
    await dataApi.deleteEvent(id);
    load();
  };

  if (loading) {
    return (
      <div className="flex justify-center py-20">
        <Loader2 className="w-8 h-8 animate-spin" style={{ color: 'var(--accent)' }} />
      </div>
    );
  }

  const selectedEvents = selected ? eventsOnDate(events, selected) : [];
  const selectedMood = selected ? moodLogs.find((l) => l.date === selected) : null;
  const topMood = selectedMood?.moods?.slice().sort((a, b) => b.intensity - a.intensity)[0];

  return (
    <div className="space-y-5 fade-up">
      <div className="flex items-center justify-between">
        <button className="hd-btn !p-2" onClick={() => nav('/')} aria-label="Back">
          <ArrowLeft className="w-5 h-5" />
        </button>
        <h1 className="text-2xl font-bold flex items-center gap-2" style={{ color: 'var(--text)' }}>
          <CalendarDays className="w-6 h-6" style={{ color: 'var(--accent)' }} /> Calendar
        </h1>
        <button className="hd-btn !p-2" onClick={() => setShowForm(!showForm)} aria-label="New event">
          <Plus className="w-5 h-5" />
        </button>
      </div>

      {showForm && (
        <div className="hd-card p-4 space-y-3">
          <h2 className="font-bold" style={{ color: 'var(--text)' }}>New Event</h2>
          <input className="hd-input" placeholder="Event name" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
          <div className="flex gap-2 flex-wrap">
            <input type="date" className="hd-input !w-auto text-sm" value={form.date} onChange={(e) => setForm({ ...form, date: e.target.value })} aria-label="Event date" />
            <div className="flex gap-1">
              {EVENT_COLORS.map((c) => (
                <button key={c} className="w-6 h-6 rounded-full border-2" style={{ background: c, borderColor: form.color === c ? 'var(--text)' : 'transparent' }} onClick={() => setForm({ ...form, color: c })} aria-label={`Color ${c}`} />
              ))}
            </div>
          </div>
          <textarea className="hd-input" rows={2} placeholder="Description (optional)" value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} />
          <label className="flex items-center gap-2 text-sm" style={{ color: 'var(--text-2)' }}>
            <input type="checkbox" checked={form.is_recurring} onChange={(e) => setForm({ ...form, is_recurring: e.target.checked })} />
            <Repeat className="w-4 h-4" /> Recurring
          </label>
          {form.is_recurring && (
            <div className="flex gap-2 flex-wrap">
              <select className="hd-input !w-auto text-sm" value={form.frequency} onChange={(e) => setForm({ ...form, frequency: e.target.value as typeof form.frequency })}>
                <option value="weekly">Weekly</option>
                <option value="monthly">Monthly</option>
                <option value="yearly">Yearly</option>
              </select>
              <label className="text-sm flex items-center gap-1" style={{ color: 'var(--text-2)' }}>
                Every
                <input type="number" min={1} className="hd-input !w-16" value={form.interval} onChange={(e) => setForm({ ...form, interval: Math.max(1, Number(e.target.value)) })} />
              </label>
              <input type="date" className="hd-input !w-auto text-sm" value={form.end_date} onChange={(e) => setForm({ ...form, end_date: e.target.value })} aria-label="Repeat until" />
            </div>
          )}
          <button className="hd-btn hd-btn-primary w-full justify-center" onClick={createEvent}>
            Create Event
          </button>
        </div>
      )}

      {/* month grid */}
      <div className="hd-card p-4">
        <div className="flex items-center justify-between mb-3">
          <button className="hd-btn !p-1.5 text-sm" onClick={() => setCursor(`${mo === 1 ? y - 1 : y}-${mo === 1 ? 12 : mo - 1 < 10 ? '0' + (mo - 1) : mo - 1}`)}>
            ←
          </button>
          <span className="font-bold" style={{ color: 'var(--text)' }}>
            {new Date(y, mo - 1).toLocaleString(undefined, { month: 'long', year: 'numeric' })}
          </span>
          <button className="hd-btn !p-1.5 text-sm" onClick={() => setCursor(`${mo === 12 ? y + 1 : y}-${mo === 12 ? '01' : mo + 1 < 10 ? '0' + (mo + 1) : mo + 1}`)}>
            →
          </button>
        </div>
        <div className="grid grid-cols-7 gap-1 text-center text-xs mb-1" style={{ color: 'var(--text-2)' }}>
          {['M', 'T', 'W', 'T', 'F', 'S', 'S'].map((d, i) => (
            <span key={i}>{d}</span>
          ))}
        </div>
        <div className="grid grid-cols-7 gap-1">
          {cells.map((d, i) => {
            if (!d) return <span key={i} />;
            const dayEvents = eventsOnDate(events, d);
            const log = moodLogs.find((l) => l.date === d);
            const moodTop = log?.moods?.slice().sort((a, b) => b.intensity - a.intensity)[0];
            const evColor = dayEvents[0]?.color;
            const isToday = d === iso(new Date());
            return (
              <button
                key={d}
                onClick={() => setSelected(selected === d ? null : d)}
                className="aspect-square rounded-lg border flex flex-col items-center justify-center text-xs relative"
                style={{
                  background: evColor ? evColor + '30' : moodTop ? moodTop.color + '22' : 'var(--surface)',
                  borderColor: selected === d ? 'var(--accent)' : isToday ? 'var(--accent)' : 'var(--border)',
                  borderWidth: isToday || selected === d ? 2 : 1,
                  color: 'var(--text)',
                }}
              >
                {Number(d.slice(8))}
                {dayEvents.length > 0 && (
                  <span className="w-1.5 h-1.5 rounded-full absolute bottom-1" style={{ background: evColor }} />
                )}
                {moodTop && !evColor && (
                  <span className="w-1.5 h-1.5 rounded-full absolute bottom-1" style={{ background: moodTop.color }} />
                )}
              </button>
            );
          })}
        </div>
        <p className="text-xs mt-2" style={{ color: 'var(--text-2)' }}>
          Dot color: event color when an event exists, otherwise the most intense primary daily mood.
        </p>
      </div>

      {/* selected day details */}
      {selected && (
        <div className="hd-card p-4 space-y-2">
          <h2 className="font-bold" style={{ color: 'var(--text)' }}>{selected}</h2>
          {topMood && (
            <p className="text-sm" style={{ color: 'var(--text-2)' }}>
              Mood: <span style={{ color: topMood.color, fontWeight: 700 }}>{topMood.label}</span> (intensity {topMood.intensity})
            </p>
          )}
          {selectedEvents.length === 0 ? (
            <p className="text-sm" style={{ color: 'var(--text-2)' }}>No events.</p>
          ) : (
            selectedEvents.map((ev) => (
              <div key={ev.id} className="flex items-center gap-2 rounded-lg p-2" style={{ background: ev.color + '18' }}>
                <span className="w-3 h-3 rounded-full" style={{ background: ev.color }} />
                <div className="flex-1 min-w-0">
                  <p className="font-semibold text-sm truncate" style={{ color: 'var(--text)' }}>
                    {ev.name}
                    {ev.is_recurring && <Repeat className="inline w-3.5 h-3.5 ml-1" style={{ color: 'var(--text-2)' }} />}
                  </p>
                  {ev.description && (
                    <p className="text-xs truncate" style={{ color: 'var(--text-2)' }}>{ev.description}</p>
                  )}
                </div>
                <button className="hd-btn !p-1.5" onClick={() => deleteEvent(ev.id)} aria-label="Delete event">
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            ))
          )}
        </div>
      )}
    </div>
  );
}
