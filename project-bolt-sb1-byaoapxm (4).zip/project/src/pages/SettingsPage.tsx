import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  ArrowLeft, Loader2, User, Palette, Languages, BellRing, Database, HardDrive, Info,
  CloudUpload, CloudDownload, Trash2, Check, LogOut, KeyRound,
} from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/lib/auth';
import { usePrefs } from '@/lib/prefs';
import { useI18n, type Lang } from '@/lib/i18n';
import { THEMES } from '@/lib/themes';
import { APP_FONTS, ENTRY_FONTS } from '@/lib/fonts';
import { dataApi } from '@/lib/data';
import { createBackup, importBackup, type BackupPreview } from '@/lib/backup';

function Section({ icon, title, children }: { icon: React.ReactNode; title: string; children: React.ReactNode }) {
  return (
    <div className="hd-card p-5">
      <h2 className="font-bold mb-3 flex items-center gap-2" style={{ color: 'var(--text)' }}>
        <span style={{ color: 'var(--accent)' }}>{icon}</span> {title}
      </h2>
      {children}
    </div>
  );
}

export default function SettingsPage() {
  const nav = useNavigate();
  const { user, profile, refreshProfile, setProfileLocal } = useAuth();
  const { prefs, setPrefs } = usePrefs();
  const { t } = useI18n();
  const [busy, setBusy] = useState(false);
  const [displayName, setDisplayName] = useState(profile?.display_name ?? '');
  const [profileMsg, setProfileMsg] = useState<string | null>(null);
  const [backupBusy, setBackupBusy] = useState(false);
  const [backupMsg, setBackupMsg] = useState<string | null>(null);
  const [backupPreview, setBackupPreview] = useState<BackupPreview | null>(null);
  const [pendingImport, setPendingImport] = useState<{ file: File; preview: BackupPreview } | null>(null);
  const [importMode, setImportMode] = useState<'merge' | 'replace'>('merge');
  const [deleteConfirm, setDeleteConfirm] = useState('');

  useEffect(() => {
    if (profile) setDisplayName(profile.display_name);
  }, [profile]);

  const saveProfile = async () => {
    if (!profile) return;
    setBusy(true);
    setProfileMsg(null);
    const { data, error } = await supabase
      .from('profiles')
      .update({ display_name: displayName.trim() || profile.display_name })
      .eq('id', profile.id)
      .select()
      .single();
    setBusy(false);
    if (error) {
      setProfileMsg(error.message);
    } else if (data) {
      setProfileLocal(data);
      setProfileMsg('Saved!');
    }
  };

  const doExport = async () => {
    setBackupBusy(true);
    setBackupMsg(null);
    try {
      const blob = await createBackup();
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `diary-bebek-backup-${new Date().toISOString().slice(0, 10)}.zip`;
      a.click();
      URL.revokeObjectURL(url);
      setPrefs({ lastBackupAt: new Date().toISOString() });
      await supabase.from('backup_log').insert({ kind: 'export', status: 'ok', detail: {} });
      setBackupMsg('Backup downloaded.');
    } catch (err) {
      setBackupMsg(err instanceof Error ? err.message : 'Backup failed');
    } finally {
      setBackupBusy(false);
    }
  };

  const onImportFile = async (file: File) => {
    setBackupMsg(null);
    try {
      const preview = await importBackup(file, 'merge', true);
      setPendingImport({ file, preview });
    } catch (err) {
      setBackupMsg(err instanceof Error ? err.message : 'Invalid backup file');
    }
  };

  const doImport = async () => {
    if (!pendingImport) return;
    setBackupBusy(true);
    try {
      await importBackup(pendingImport.file, importMode, false);
      await supabase.from('backup_log').insert({ kind: 'import', status: 'ok', detail: { mode: importMode } });
      setBackupMsg(`Restored (${importMode}). Reload to see your data.`);
      setPendingImport(null);
    } catch (err) {
      setBackupMsg(err instanceof Error ? err.message : 'Import failed — your data was not changed.');
    } finally {
      setBackupBusy(false);
    }
  };

  const deleteAccount = async () => {
    if (deleteConfirm !== 'DELETE') return;
    // Supabase requires server-side deletion; sign out locally.
    // The account row remains until server-side deletion is configured.
    await supabase.auth.signOut();
  };

  return (
    <div className="space-y-5 fade-up pb-10">
      <div className="flex items-center justify-between">
        <button className="hd-btn !p-2" onClick={() => nav('/')} aria-label="Back">
          <ArrowLeft className="w-5 h-5" />
        </button>
        <h1 className="text-2xl font-bold" style={{ color: 'var(--text)' }}>
          {t('settings')}
        </h1>
        <span className="w-10" />
      </div>

      {/* profile */}
      <Section icon={<User className="w-5 h-5" />} title={t('profile')}>
        <div className="space-y-3">
          <div className="flex gap-3 items-center flex-wrap">
            <div>
              <label className="text-xs" style={{ color: 'var(--text-2)' }}>{t('displayName')}</label>
              <input className="hd-input" value={displayName} onChange={(e) => setDisplayName(e.target.value)} />
            </div>
            <div>
              <label className="text-xs" style={{ color: 'var(--text-2)' }}>{t('username')}</label>
              <input className="hd-input opacity-60" value={profile ? '@' + profile.username : ''} disabled />
            </div>
            <div>
              <label className="text-xs" style={{ color: 'var(--text-2)' }}>{t('email')}</label>
              <input className="hd-input opacity-60" value={user?.email ?? ''} disabled />
            </div>
          </div>
          <button className="hd-btn hd-btn-primary text-sm" onClick={saveProfile} disabled={busy}>
            {busy ? <Loader2 className="w-4 h-4 animate-spin" /> : <Check className="w-4 h-4" />} {t('save')}
          </button>
          {profileMsg && <p className="text-sm" style={{ color: 'var(--success)' }}>{profileMsg}</p>}
        </div>
      </Section>

      {/* appearance */}
      <Section icon={<Palette className="w-5 h-5" />} title={t('appearance')}>
        <div className="space-y-4">
          <div>
            <p className="text-sm font-semibold mb-2" style={{ color: 'var(--text-2)' }}>{t('appTheme')}</p>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {THEMES.map((th) => (
                <button
                  key={th.id}
                  className="hd-btn justify-center"
                  style={prefs.theme === th.id ? { background: 'var(--surface-2)', borderColor: 'var(--accent)' } : {}}
                  onClick={() => setPrefs({ theme: th.id })}
                >
                  {th.id === 'light' ? '☀️' : th.id === 'dark' ? '🌙' : th.id === 'autumn' ? '🍂' : '💙'} {th.label.en}
                </button>
              ))}
            </div>
          </div>
          <div className="grid sm:grid-cols-2 gap-4">
            <div>
              <p className="text-sm font-semibold mb-2" style={{ color: 'var(--text-2)' }}>{t('appFont')}</p>
              <select className="hd-input" value={prefs.appFontId} onChange={(e) => setPrefs({ appFontId: e.target.value })} style={{ fontFamily: 'inherit' }}>
                {APP_FONTS.map((f) => (
                  <option key={f.id} value={f.id}>{f.name}</option>
                ))}
              </select>
            </div>
            <div>
              <p className="text-sm font-semibold mb-2" style={{ color: 'var(--text-2)' }}>{t('defaultEntryFont')}</p>
              <select className="hd-input" value={prefs.entryFontId} onChange={(e) => setPrefs({ entryFontId: e.target.value })}>
                {ENTRY_FONTS.map((f) => (
                  <option key={f.id} value={f.id}>{f.name}</option>
                ))}
              </select>
            </div>
          </div>
        </div>
      </Section>

      {/* language */}
      <Section icon={<Languages className="w-5 h-5" />} title={t('language')}>
        <div className="flex gap-2">
          <button
            className="hd-btn"
            style={prefs.lang === 'en' ? { background: 'var(--surface-2)', borderColor: 'var(--accent)' } : {}}
            onClick={() => setPrefs({ lang: 'en' })}
          >
            {t('english')}
          </button>
          <button
            className="hd-btn"
            style={prefs.lang === 'device' ? { background: 'var(--surface-2)', borderColor: 'var(--accent)' } : {}}
            onClick={() => setPrefs({ lang: 'device' })}
          >
            {t('deviceLanguage')}
          </button>
        </div>
      </Section>

      {/* reminders */}
      <Section icon={<BellRing className="w-5 h-5" />} title={t('reminders')}>
        <button
          className="hd-btn text-sm"
          onClick={async () => {
            if ('Notification' in window) {
              const perm = await Notification.requestPermission();
              if (perm === 'granted') {
                new Notification('Diary Bebek', { body: 'Reminders enabled in this browser.' });
              }
            }
          }}
        >
          <BellRing className="w-4 h-4" /> Enable browser notifications
        </button>
        <p className="text-xs mt-2" style={{ color: 'var(--text-2)' }}>
          Reminders fire while the app is open. Background push requires native platform support — calendar events are shown on the Home page as an in-app fallback.
        </p>
      </Section>

      {/* data & backup */}
      <Section icon={<Database className="w-5 h-5" />} title={t('dataBackup')}>
        <div className="space-y-3">
          <p className="text-sm" style={{ color: 'var(--text-2)' }}>
            {t('lastBackup')}: {prefs.lastBackupAt ? new Date(prefs.lastBackupAt).toLocaleString() : t('never')}
          </p>
          <div className="flex gap-2 flex-wrap">
            <button className="hd-btn hd-btn-primary text-sm" onClick={doExport} disabled={backupBusy}>
              <CloudUpload className="w-4 h-4" /> {t('exportBackup')}
            </button>
            <label className="hd-btn text-sm cursor-pointer">
              <CloudDownload className="w-4 h-4" /> {t('importBackup')}
              <input
                type="file"
                accept=".zip"
                className="hidden"
                onChange={(e) => {
                  const f = e.target.files?.[0];
                  if (f) onImportFile(f);
                }}
              />
            </label>
          </div>
          {backupBusy && <Loader2 className="w-5 h-5 animate-spin" style={{ color: 'var(--accent)' }} />}
          {backupMsg && <p className="text-sm" style={{ color: 'var(--success)' }}>{backupMsg}</p>}

          {pendingImport && (
            <div className="hd-border rounded-xl p-3 space-y-2" style={{ background: 'var(--surface-2)' }}>
              <p className="text-sm font-bold" style={{ color: 'var(--text)' }}>Backup contents</p>
              <p className="text-xs" style={{ color: 'var(--text-2)' }}>
                {pendingImport.preview.entries} entries · {pendingImport.preview.tags} tags · {pendingImport.preview.folders} folders ·{' '}
                {pendingImport.preview.moodLogs} mood logs · {pendingImport.preview.events} events · {pendingImport.preview.compilations} compilations ·{' '}
                {pendingImport.preview.mediaFiles} media files (v{pendingImport.preview.version})
              </p>
              <div className="flex gap-2 items-center flex-wrap">
                <select className="hd-input !w-auto text-sm" value={importMode} onChange={(e) => setImportMode(e.target.value as 'merge' | 'replace')}>
                  <option value="merge">Merge with existing data</option>
                  <option value="replace">Replace existing data</option>
                </select>
                <button className="hd-btn hd-btn-primary text-sm" onClick={doImport} disabled={backupBusy}>
                  Restore
                </button>
                <button className="hd-btn text-sm" onClick={() => setPendingImport(null)}>
                  {t('cancel')}
                </button>
              </div>
              {importMode === 'replace' && (
                <p className="text-xs" style={{ color: 'var(--error)' }}>
                  Replace will first delete your current entries, tags, folders, mood logs, events and compilations in the cloud, then restore the backup. This cannot be undone.
                </p>
              )}
            </div>
          )}
        </div>
      </Section>

      {/* storage */}
      <Section icon={<HardDrive className="w-5 h-5" />} title={t('storage')}>
        <p className="text-sm" style={{ color: 'var(--text-2)' }}>
          Uploaded photos and audio are stored privately in cloud storage, scoped to your account. Images are limited to 15 MB each.
        </p>
      </Section>

      {/* account */}
      <Section icon={<KeyRound className="w-5 h-5" />} title={t('accountSecurity')}>
        <div className="space-y-3">
          <button
            className="hd-btn text-sm"
            onClick={async () => {
              await supabase.auth.signOut();
            }}
          >
            <LogOut className="w-4 h-4" /> {t('signOut')}
          </button>
          <div>
            <p className="text-sm font-semibold mb-1" style={{ color: 'var(--error)' }}>Delete account</p>
            <p className="text-xs mb-2" style={{ color: 'var(--text-2)' }}>
              Type DELETE to confirm. This signs you out now; full server-side deletion is performed on request.
            </p>
            <div className="flex gap-2">
              <input className="hd-input !w-40" value={deleteConfirm} onChange={(e) => setDeleteConfirm(e.target.value)} placeholder="DELETE" />
              <button className="hd-btn text-sm" style={{ color: 'var(--error)' }} disabled={deleteConfirm !== 'DELETE'} onClick={deleteAccount}>
                <Trash2 className="w-4 h-4" /> Delete
              </button>
            </div>
          </div>
        </div>
      </Section>

      {/* about */}
      <Section icon={<Info className="w-5 h-5" />} title={t('about')}>
        <p className="text-sm" style={{ color: 'var(--text-2)' }}>
          Diary Bebek v1.0 — a cute personal journal. Your entries are private and protected by row-level security; only you can read or change them.
        </p>
      </Section>
    </div>
  );
}
