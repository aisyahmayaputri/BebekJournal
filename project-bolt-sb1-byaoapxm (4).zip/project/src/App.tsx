import { useMemo } from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { I18nProvider } from '@/lib/i18n';
import { PrefsProvider, usePrefs } from '@/lib/prefs';
import { AuthProvider, useAuth } from '@/lib/auth';
import AuthPage from '@/pages/AuthPage';
import HomePage from '@/pages/HomePage';
import LibraryPage from '@/pages/LibraryPage';
import EntryEditorPage from '@/pages/EntryEditorPage';
import MoodTrackerPage from '@/pages/MoodTrackerPage';
import CalendarPage from '@/pages/CalendarPage';
import GalleryPage from '@/pages/GalleryPage';
import MemoriesPage from '@/pages/MemoriesPage';
import StatsPage from '@/pages/StatsPage';
import SettingsPage from '@/pages/SettingsPage';
import FoldersPage from '@/pages/FoldersPage';
import CompilationsPage from '@/pages/CompilationsPage';
import SearchPage from '@/pages/SearchPage';

function AppRoutes() {
  const { session, loading } = useAuth();
  const { prefs, setPrefs } = usePrefs();

  const i18nValue = useMemo(
    () => ({
      lang: prefs.lang,
      setLang: (l: 'en' | 'device') => setPrefs({ lang: l }),
    }),
    [prefs.lang, setPrefs]
  );

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ background: 'var(--bg)' }}>
        <div className="hd-card px-8 py-6 text-lg font-bold" style={{ color: 'var(--text)' }}>
          Diary Bebek…
        </div>
      </div>
    );
  }

  return (
    <I18nProvider lang={i18nValue.lang} setLang={i18nValue.setLang}>
      {!session ? (
        <AuthPage />
      ) : (
        <div className="min-h-screen" style={{ background: 'var(--bg)' }}>
          <div className="max-w-3xl mx-auto px-4 py-5 pb-24">
            <Routes>
              <Route path="/" element={<HomePage />} />
              <Route path="/library" element={<LibraryPage />} />
              <Route path="/entry/:id" element={<EntryEditorPage />} />
              <Route path="/editor/new" element={<EntryEditorPage />} />

              <Route path="/moods" element={<MoodTrackerPage />} />
              <Route path="/calendar" element={<CalendarPage />} />
              <Route path="/gallery" element={<GalleryPage />} />
              <Route path="/memories" element={<MemoriesPage />} />
              <Route path="/stats" element={<StatsPage />} />
              <Route path="/settings" element={<SettingsPage />} />
              <Route path="/folders" element={<FoldersPage />} />
              <Route path="/compilations" element={<CompilationsPage />} />
              <Route path="/search" element={<SearchPage />} />
              <Route path="*" element={<Navigate to="/" replace />} />
            </Routes>
          </div>
          <NavBar />
        </div>
      )}
    </I18nProvider>
  );
}

// compact bottom navigation for quick access on small screens
function NavBar() {
  return null;
}

export default function App() {
  return (
    <BrowserRouter>
      <PrefsProvider>
        <AuthProvider>
          <AppRoutes />
        </AuthProvider>
      </PrefsProvider>
    </BrowserRouter>
  );
}
