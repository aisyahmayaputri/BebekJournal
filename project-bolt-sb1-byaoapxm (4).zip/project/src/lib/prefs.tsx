import { createContext, useContext, useEffect, useState, type ReactNode } from 'react';
import type { ThemeName } from '@/lib/themes';
import { fontStackFor } from '@/lib/fonts';
import type { Lang } from '@/lib/i18n';

export interface Prefs {
  theme: ThemeName;
  appFontId: string;
  entryFontId: string;
  lang: Lang;
  lastBackupAt: string | null;
  autoBackup: 'off' | 'weekly' | 'monthly';
}

const DEFAULT_PREFS: Prefs = {
  theme: 'light',
  appFontId: 'gaegu',
  entryFontId: 'patrick',
  lang: 'en',
  lastBackupAt: null,
  autoBackup: 'off',
};

interface Ctx {
  prefs: Prefs;
  setPrefs: (p: Partial<Prefs>) => void;
}

const PrefCtx = createContext<Ctx>({ prefs: DEFAULT_PREFS, setPrefs: () => {} });

export function PrefsProvider({ children }: { children: ReactNode }) {
  const [prefs, setPrefsState] = useState<Prefs>(() => {
    try {
      const raw = localStorage.getItem('db_prefs');
      if (raw) return { ...DEFAULT_PREFS, ...JSON.parse(raw) };
    } catch {
      /* ignore */
    }
    return DEFAULT_PREFS;
  });

  const setPrefs = (p: Partial<Prefs>) => {
    setPrefsState((prev) => {
      const next = { ...prev, ...p };
      try {
        localStorage.setItem('db_prefs', JSON.stringify(next));
      } catch {
        /* ignore */
      }
      return next;
    });
  };

  useEffect(() => {
    document.documentElement.setAttribute('data-theme', prefs.theme);
    document.documentElement.style.setProperty('--app-font', fontStackFor(prefs.appFontId));
  }, [prefs.theme, prefs.appFontId]);

  return <PrefCtx.Provider value={{ prefs, setPrefs }}>{children}</PrefCtx.Provider>;
}

export function usePrefs() {
  return useContext(PrefCtx);
}

export { DEFAULT_PREFS };
