import { createContext, useContext, useEffect, useMemo, useState, type ReactNode } from 'react';

export type Lang = 'en' | 'device';

const STRINGS: Record<string, { en: string; device?: string }> = {
  // nav / common
  allJournals: { en: 'All Journals' },
  moodTracker: { en: 'Mood Tracker' },
  settings: { en: 'Settings' },
  gallery: { en: 'Gallery' },
  library: { en: 'Library' },
  memories: { en: 'Memories' },
  statistics: { en: 'Statistics' },
  save: { en: 'Save' },
  cancel: { en: 'Cancel' },
  delete: { en: 'Delete' },
  edit: { en: 'Edit' },
  done: { en: 'Done' },
  search: { en: 'Search' },
  loading: { en: 'Loading…' },
  newEntry: { en: 'New Entry' },
  // greeting
  goodMorning: { en: 'Good morning' },
  goodAfternoon: { en: 'Good afternoon' },
  goodEvening: { en: 'Good evening' },
  greetingLine1: { en: 'Ready to write something lovely today?' },
  greetingLine2: { en: 'Your diary is waiting for you.' },
  greetingLine3: { en: "Today's pages are blank and full of possibility." },
  greetingLine4: { en: 'A little memory a day keeps forgetting away.' },
  // home
  quickAccess: { en: 'Quick Access' },
  bookOfTheYear: { en: 'Book of the Year' },
  movieOfTheYear: { en: 'Movie of the Year' },
  allBooks: { en: 'All Books' },
  allMovies: { en: 'All Movies' },
  frequentlyVisited: { en: 'Frequently Visited' },
  today: { en: 'Today' },
  // mood
  howAreYouFeeling: { en: 'How are you feeling?' },
  intensity: { en: 'Intensity' },
  saveMood: { en: 'Save Mood' },
  editMood: { en: 'Edit Mood' },
  moodSaved: { en: 'Mood saved!' },
  noMoodYet: { en: 'No mood logged yet today.' },
  // auth
  welcomeBack: { en: 'Welcome back' },
  createAccount: { en: 'Create Account' },
  signIn: { en: 'Sign In' },
  signOut: { en: 'Sign Out' },
  email: { en: 'Email' },
  username: { en: 'Username' },
  displayName: { en: 'Display Name' },
  password: { en: 'Password' },
  forgotPassword: { en: 'Forgot password?' },
  resetPassword: { en: 'Reset Password' },
  signInWithGoogle: { en: 'Sign in with Google' },
  // settings
  profile: { en: 'Profile' },
  accountSecurity: { en: 'Account & Security' },
  appearance: { en: 'Appearance' },
  language: { en: 'Language' },
  english: { en: 'English' },
  deviceLanguage: { en: 'Device language' },
  reminders: { en: 'Reminders' },
  dataBackup: { en: 'Data & Backup' },
  storage: { en: 'Storage' },
  about: { en: 'About' },
  appTheme: { en: 'App Theme' },
  appFont: { en: 'App Font' },
  defaultEntryFont: { en: 'Default Entry Font' },
  exportBackup: { en: 'Export Backup' },
  importBackup: { en: 'Import Backup' },
  lastBackup: { en: 'Last backup' },
  never: { en: 'Never' },
  // library
  filterByTag: { en: 'Filter by tag' },
  filterByType: { en: 'Filter by type' },
  filterByFolder: { en: 'Filter by folder' },
  noEntries: { en: 'Nothing here yet. Your first entry awaits!' },
  // entry types
  diary: { en: 'Diary' },
  movie: { en: 'Movie' },
  book: { en: 'Book' },
  hangout: { en: 'Hangout' },
  // misc
  booksYouRead: { en: 'books you read' },
  moviesYouWatched: { en: 'movies you watched' },
  noBooksYet: { en: 'No books recorded this year yet.' },
  noMoviesYet: { en: 'No movies recorded this year yet.' },
  placesYouLove: { en: 'Places you love' },
  noPlacesYet: { en: 'Places from your hangout entries will appear here.' },
  visits: { en: 'visits' },
  rating: { en: 'Rating' },
  deleteEntryConfirm: { en: 'Delete this entry? This cannot be undone.' },
};

export type StringKey = keyof typeof STRINGS;

interface I18nCtx {
  lang: Lang;
  setLang: (l: Lang) => void;
  t: (key: StringKey) => string;
}

const Ctx = createContext<I18nCtx>({
  lang: 'en',
  setLang: () => {},
  t: (k) => STRINGS[k]?.en ?? String(k),
});

function detectDeviceLang(): string {
  if (typeof navigator === 'undefined') return 'en';
  const l = (navigator.languages?.[0] || navigator.language || 'en').toLowerCase();
  if (l.startsWith('en')) return 'en';
  return l.split('-')[0];
}

export function I18nProvider({
  children,
  lang,
  setLang,
}: {
  children: ReactNode;
  lang: Lang;
  setLang: (l: Lang) => void;
}) {
  const value = useMemo<I18nCtx>(() => {
    const device = detectDeviceLang();
    const t = (key: StringKey) => {
      const s = STRINGS[key];
      if (!s) return String(key);
      return lang === 'device' ? s.device ?? s.en : s.en;
    };
    return { lang, setLang, t };
  }, [lang, setLang]);
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useI18n() {
  return useContext(Ctx);
}

// resolve a device-language string
export function deviceOrEn(lang: Lang, key: StringKey): string {
  const s = STRINGS[key];
  return lang === 'device' ? s?.device ?? s?.en ?? key : s?.en ?? key;
}

export { detectDeviceLang };
