/*
# Harden trigger functions

1. Security fixes
- Revoke EXECUTE on `handle_new_user` from anon/authenticated so it cannot be called directly via RPC — it only runs via the auth trigger.
- Pin search_path on `set_updated_at`.

2. No data changes.
*/

REVOKE EXECUTE ON FUNCTION public.handle_new_user() FROM anon, authenticated, public;
ALTER FUNCTION public.set_updated_at() SET search_path = public;