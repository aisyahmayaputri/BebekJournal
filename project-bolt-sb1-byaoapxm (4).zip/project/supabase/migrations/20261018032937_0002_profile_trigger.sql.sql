/*
# Profile creation trigger + built-in moods

1. Functions
- `handle_new_user()`: SECURITY DEFINER trigger on new auth users. Creates a `profiles` row with a unique username (email prefix, sanitized, numeric suffix on collision) and display name. Seeds the 15 built-in moods.

2. Security
- SECURITY DEFINER with pinned search_path.
*/

CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS trigger AS $$
DECLARE
  base text;
  candidate text;
  suffix int := 0;
BEGIN
  base := lower(regexp_replace(split_part(new.email, '@', 1), '[^a-z0-9_]', '', 'g'));
  IF base IS NULL OR base = '' THEN
    base := 'diary';
  END IF;
  IF length(base) > 20 THEN
    base := left(base, 20);
    base := rtrim(base, '_');
  END IF;
  candidate := base;
  WHILE EXISTS (SELECT 1 FROM profiles WHERE username = candidate) LOOP
    suffix := suffix + 1;
    candidate := base || suffix::text;
  END LOOP;
  INSERT INTO profiles (id, username, display_name)
  VALUES (new.id, candidate, split_part(new.email, '@', 1));
  INSERT INTO moods (user_id, label, color, sort_order)
  SELECT new.id, m.label, '#B99A79', m.ord
  FROM (VALUES
    ('Happy',1),('Calm',2),('Excited',3),('Grateful',4),('Loved',5),
    ('Hopeful',6),('Content',7),('Nostalgic',8),('Anxious',9),('Sad',10),
    ('Angry',11),('Frustrated',12),('Lonely',13),('Tired',14),('Overwhelmed',15)
  ) AS m(label, ord);
  RETURN new;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
AFTER INSERT ON auth.users
FOR EACH ROW EXECUTE FUNCTION handle_new_user();
