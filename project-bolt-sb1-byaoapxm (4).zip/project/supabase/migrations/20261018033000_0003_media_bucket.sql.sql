/*
# Private media storage bucket

1. Storage
- Creates a private bucket `media` for user uploads (images, audio).
- Owner-scoped policies: authenticated users read/upload/update/delete only within their own `user_id/` folder prefix.
- Folder layout: `{user_id}/{entry_id or arbitrary}/filename`.

2. Security
- Bucket is PRIVATE; access goes through signed URLs or authenticated fetches.
- Path-prefix ownership checks prevent cross-user access.
*/

INSERT INTO storage.buckets (id, name, public)
VALUES ('media', 'media', false)
ON CONFLICT (id) DO NOTHING;

DROP POLICY IF EXISTS "media read own prefix" ON storage.objects;
CREATE POLICY "media read own prefix" ON storage.objects FOR SELECT
TO authenticated
USING (bucket_id = 'media' AND (storage.foldername(name))[1] = auth.uid()::text);

DROP POLICY IF EXISTS "media insert own prefix" ON storage.objects;
CREATE POLICY "media insert own prefix" ON storage.objects FOR INSERT
TO authenticated
WITH CHECK (bucket_id = 'media' AND (storage.foldername(name))[1] = auth.uid()::text);

DROP POLICY IF EXISTS "media update own prefix" ON storage.objects;
CREATE POLICY "media update own prefix" ON storage.objects FOR UPDATE
TO authenticated
USING (bucket_id = 'media' AND (storage.foldername(name))[1] = auth.uid()::text)
WITH CHECK (bucket_id = 'media' AND (storage.foldername(name))[1] = auth.uid()::text);

DROP POLICY IF EXISTS "media delete own prefix" ON storage.objects;
CREATE POLICY "media delete own prefix" ON storage.objects FOR DELETE
TO authenticated
USING (bucket_id = 'media' AND (storage.foldername(name))[1] = auth.uid()::text);