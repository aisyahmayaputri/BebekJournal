/*
# Diary Bebek — core schema

1. New tables
- `profiles`: one row per user. `id` = auth user id. `username` unique, `display_name`, `avatar_url`, `preferences` jsonb.
- `folders`: user folders (name, description, color, icon, cover).
- `tags`: user tags (name, chip_bg, chip_text).
- `entries`: central journal records. `type` (diary|movie|book|hangout), `title`, `date` (user-set original date; library sorts by it), `content` (rich text HTML), `blocks` jsonb (structured per-type fields, theme, layout, drawing layers, media transforms, moods, rating). `pinned_home`, `pinned_folder`.
- `entry_tags` / `entry_folders`: join tables with unique pairs.
- `moods`: user emotion library (label, color, icon, sort order).
- `mood_logs`: primary daily mood log, one row per user per day (unique user_id+date), `moods` jsonb array with intensities.
- `events`: calendar events with optional recurrence jsonb.
- `reminders`: reminders, optionally linked to events.
- `compilations`: compiled journals with ordered `source_ids` and immutable `snapshot` jsonb.
- `backup_log`: export/import history.

2. Modified tables
- none (fresh schema).

3. Security
- RLS enabled on every table; all policies owner-scoped with `auth.uid()`.
- Owner columns default to `auth.uid()` so client inserts omitting user_id still pass.
- Join tables scoped via ownership of the parent entry.
- updated_at kept fresh by a trigger on entries.
*/

CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  username text UNIQUE NOT NULL,
  display_name text NOT NULL,
  avatar_url text,
  preferences jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS folders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  name text NOT NULL,
  description text NOT NULL DEFAULT '',
  color text NOT NULL DEFAULT '#B99A79',
  icon text NOT NULL DEFAULT 'folder',
  cover_url text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS tags (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  name text NOT NULL,
  chip_bg text NOT NULL DEFAULT '#F0E8DA',
  chip_text text NOT NULL DEFAULT '#49382E',
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS entries (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  type text NOT NULL DEFAULT 'diary' CHECK (type IN ('diary','movie','book','hangout')),
  title text NOT NULL DEFAULT '',
  date date NOT NULL DEFAULT CURRENT_DATE,
  content text NOT NULL DEFAULT '',
  blocks jsonb NOT NULL DEFAULT '{}'::jsonb,
  pinned_home boolean NOT NULL DEFAULT false,
  pinned_folder boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS entry_tags (
  entry_id uuid NOT NULL REFERENCES entries(id) ON DELETE CASCADE,
  tag_id uuid NOT NULL REFERENCES tags(id) ON DELETE CASCADE,
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  PRIMARY KEY (entry_id, tag_id)
);

CREATE TABLE IF NOT EXISTS entry_folders (
  entry_id uuid NOT NULL REFERENCES entries(id) ON DELETE CASCADE,
  folder_id uuid NOT NULL REFERENCES folders(id) ON DELETE CASCADE,
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  PRIMARY KEY (entry_id, folder_id)
);

CREATE TABLE IF NOT EXISTS moods (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  label text NOT NULL,
  color text NOT NULL DEFAULT '#B99A79',
  icon_name text NOT NULL DEFAULT 'smile',
  sort_order int NOT NULL DEFAULT 0,
  is_builtin boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS mood_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  date date NOT NULL,
  moods jsonb NOT NULL DEFAULT '[]'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, date)
);

CREATE TABLE IF NOT EXISTS events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  name text NOT NULL,
  date date NOT NULL,
  description text NOT NULL DEFAULT '',
  color text NOT NULL DEFAULT '#B99A79',
  is_recurring boolean NOT NULL DEFAULT false,
  recurrence jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS reminders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  event_id uuid REFERENCES events(id) ON DELETE CASCADE,
  label text NOT NULL,
  time timestamptz,
  enabled boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS compilations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  title text NOT NULL,
  cover_url text,
  theme jsonb,
  source_ids uuid[] NOT NULL DEFAULT '{}',
  snapshot jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS backup_log (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  kind text CHECK (kind IN ('export','import')),
  status text,
  detail jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE folders ENABLE ROW LEVEL SECURITY;
ALTER TABLE tags ENABLE ROW LEVEL SECURITY;
ALTER TABLE entries ENABLE ROW LEVEL SECURITY;
ALTER TABLE entry_tags ENABLE ROW LEVEL SECURITY;
ALTER TABLE entry_folders ENABLE ROW LEVEL SECURITY;
ALTER TABLE moods ENABLE ROW LEVEL SECURITY;
ALTER TABLE mood_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE events ENABLE ROW LEVEL SECURITY;
ALTER TABLE reminders ENABLE ROW LEVEL SECURITY;
ALTER TABLE compilations ENABLE ROW LEVEL SECURITY;
ALTER TABLE backup_log ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "profiles select own" ON profiles;
CREATE POLICY "profiles select own" ON profiles FOR SELECT TO authenticated USING (auth.uid() = id);
DROP POLICY IF EXISTS "profiles insert own" ON profiles;
CREATE POLICY "profiles insert own" ON profiles FOR INSERT TO authenticated WITH CHECK (auth.uid() = id);
DROP POLICY IF EXISTS "profiles update own" ON profiles;
CREATE POLICY "profiles update own" ON profiles FOR UPDATE TO authenticated USING (auth.uid() = id) WITH CHECK (auth.uid() = id);

DROP POLICY IF EXISTS "folders select own" ON folders;
CREATE POLICY "folders select own" ON folders FOR SELECT TO authenticated USING (auth.uid() = user_id);
DROP POLICY IF EXISTS "folders insert own" ON folders;
CREATE POLICY "folders insert own" ON folders FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
DROP POLICY IF EXISTS "folders update own" ON folders;
CREATE POLICY "folders update own" ON folders FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
DROP POLICY IF EXISTS "folders delete own" ON folders;
CREATE POLICY "folders delete own" ON folders FOR DELETE TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "tags select own" ON tags;
CREATE POLICY "tags select own" ON tags FOR SELECT TO authenticated USING (auth.uid() = user_id);
DROP POLICY IF EXISTS "tags insert own" ON tags;
CREATE POLICY "tags insert own" ON tags FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
DROP POLICY IF EXISTS "tags update own" ON tags;
CREATE POLICY "tags update own" ON tags FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
DROP POLICY IF EXISTS "tags delete own" ON tags;
CREATE POLICY "tags delete own" ON tags FOR DELETE TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "entries select own" ON entries;
CREATE POLICY "entries select own" ON entries FOR SELECT TO authenticated USING (auth.uid() = user_id);
DROP POLICY IF EXISTS "entries insert own" ON entries;
CREATE POLICY "entries insert own" ON entries FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
DROP POLICY IF EXISTS "entries update own" ON entries;
CREATE POLICY "entries update own" ON entries FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
DROP POLICY IF EXISTS "entries delete own" ON entries;
CREATE POLICY "entries delete own" ON entries FOR DELETE TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "entry_tags select own" ON entry_tags;
CREATE POLICY "entry_tags select own" ON entry_tags FOR SELECT TO authenticated USING (EXISTS (SELECT 1 FROM entries e WHERE e.id = entry_tags.entry_id AND e.user_id = auth.uid()));
DROP POLICY IF EXISTS "entry_tags insert own" ON entry_tags;
CREATE POLICY "entry_tags insert own" ON entry_tags FOR INSERT TO authenticated WITH CHECK (EXISTS (SELECT 1 FROM entries e WHERE e.id = entry_tags.entry_id AND e.user_id = auth.uid()));
DROP POLICY IF EXISTS "entry_tags delete own" ON entry_tags;
CREATE POLICY "entry_tags delete own" ON entry_tags FOR DELETE TO authenticated USING (EXISTS (SELECT 1 FROM entries e WHERE e.id = entry_tags.entry_id AND e.user_id = auth.uid()));

DROP POLICY IF EXISTS "entry_folders select own" ON entry_folders;
CREATE POLICY "entry_folders select own" ON entry_folders FOR SELECT TO authenticated USING (EXISTS (SELECT 1 FROM entries e WHERE e.id = entry_folders.entry_id AND e.user_id = auth.uid()));
DROP POLICY IF EXISTS "entry_folders insert own" ON entry_folders;
CREATE POLICY "entry_folders insert own" ON entry_folders FOR INSERT TO authenticated WITH CHECK (EXISTS (SELECT 1 FROM entries e WHERE e.id = entry_folders.entry_id AND e.user_id = auth.uid()));
DROP POLICY IF EXISTS "entry_folders delete own" ON entry_folders;
CREATE POLICY "entry_folders delete own" ON entry_folders FOR DELETE TO authenticated USING (EXISTS (SELECT 1 FROM entries e WHERE e.id = entry_folders.entry_id AND e.user_id = auth.uid()));

DROP POLICY IF EXISTS "moods select own" ON moods;
CREATE POLICY "moods select own" ON moods FOR SELECT TO authenticated USING (auth.uid() = user_id);
DROP POLICY IF EXISTS "moods insert own" ON moods;
CREATE POLICY "moods insert own" ON moods FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
DROP POLICY IF EXISTS "moods update own" ON moods;
CREATE POLICY "moods update own" ON moods FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
DROP POLICY IF EXISTS "moods delete own" ON moods;
CREATE POLICY "moods delete own" ON moods FOR DELETE TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "mood_logs select own" ON mood_logs;
CREATE POLICY "mood_logs select own" ON mood_logs FOR SELECT TO authenticated USING (auth.uid() = user_id);
DROP POLICY IF EXISTS "mood_logs insert own" ON mood_logs;
CREATE POLICY "mood_logs insert own" ON mood_logs FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
DROP POLICY IF EXISTS "mood_logs update own" ON mood_logs;
CREATE POLICY "mood_logs update own" ON mood_logs FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
DROP POLICY IF EXISTS "mood_logs delete own" ON mood_logs;
CREATE POLICY "mood_logs delete own" ON mood_logs FOR DELETE TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "events select own" ON events;
CREATE POLICY "events select own" ON events FOR SELECT TO authenticated USING (auth.uid() = user_id);
DROP POLICY IF EXISTS "events insert own" ON events;
CREATE POLICY "events insert own" ON events FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
DROP POLICY IF EXISTS "events update own" ON events;
CREATE POLICY "events update own" ON events FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
DROP POLICY IF EXISTS "events delete own" ON events;
CREATE POLICY "events delete own" ON events FOR DELETE TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "reminders select own" ON reminders;
CREATE POLICY "reminders select own" ON reminders FOR SELECT TO authenticated USING (auth.uid() = user_id);
DROP POLICY IF EXISTS "reminders insert own" ON reminders;
CREATE POLICY "reminders insert own" ON reminders FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
DROP POLICY IF EXISTS "reminders update own" ON reminders;
CREATE POLICY "reminders update own" ON reminders FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
DROP POLICY IF EXISTS "reminders delete own" ON reminders;
CREATE POLICY "reminders delete own" ON reminders FOR DELETE TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "compilations select own" ON compilations;
CREATE POLICY "compilations select own" ON compilations FOR SELECT TO authenticated USING (auth.uid() = user_id);
DROP POLICY IF EXISTS "compilations insert own" ON compilations;
CREATE POLICY "compilations insert own" ON compilations FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
DROP POLICY IF EXISTS "compilations update own" ON compilations;
CREATE POLICY "compilations update own" ON compilations FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
DROP POLICY IF EXISTS "compilations delete own" ON compilations;
CREATE POLICY "compilations delete own" ON compilations FOR DELETE TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "backup_log select own" ON backup_log;
CREATE POLICY "backup_log select own" ON backup_log FOR SELECT TO authenticated USING (auth.uid() = user_id);
DROP POLICY IF EXISTS "backup_log insert own" ON backup_log;
CREATE POLICY "backup_log insert own" ON backup_log FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);

CREATE INDEX IF NOT EXISTS entries_user_date_idx ON entries (user_id, date DESC);
CREATE INDEX IF NOT EXISTS entry_tags_tag_idx ON entry_tags (tag_id);
CREATE INDEX IF NOT EXISTS entry_folders_folder_idx ON entry_folders (folder_id);
CREATE INDEX IF NOT EXISTS mood_logs_user_date_idx ON mood_logs (user_id, date DESC);
CREATE INDEX IF NOT EXISTS events_user_date_idx ON events (user_id, date);
CREATE INDEX IF NOT EXISTS folders_user_idx ON folders (user_id);
CREATE INDEX IF NOT EXISTS tags_user_idx ON tags (user_id);
CREATE INDEX IF NOT EXISTS moods_user_sort_idx ON moods (user_id, sort_order);

CREATE OR REPLACE FUNCTION set_updated_at() RETURNS trigger AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS entries_updated_at ON entries;
CREATE TRIGGER entries_updated_at BEFORE UPDATE ON entries FOR EACH ROW EXECUTE FUNCTION set_updated_at();